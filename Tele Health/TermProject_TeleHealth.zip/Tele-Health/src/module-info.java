module Bookshop{
	requires java.desktop;
	requires java.sql;
}