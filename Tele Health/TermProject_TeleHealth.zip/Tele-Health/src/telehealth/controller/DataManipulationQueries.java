package telehealth.controller;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.Calendar;
import java.util.Date;

public class DataManipulationQueries implements IDataManipulation {
	Connection con = null;
	Statement stmt = null;
	ResultSet rs = null;
	private static DataManipulationQueries inst;

	public static DataManipulationQueries getInst() {
		if (inst == null) {
			inst = new DataManipulationQueries();
		}
		return inst;
	}

	@Override
	public void register(String name, String username, String email, String mobile, String password,
			String user_address) {
		try {
			Class.forName(IDataBaseConnection.DRIVER);
			con = DriverManager.getConnection(IDataBaseConnection.URL, IDataBaseConnection.USER_NAME,
					IDataBaseConnection.PASSWORD);
			stmt = con.createStatement();
			PreparedStatement pst = con.prepareStatement(
					"insert into patient(name,username,email,mobileNo,password,address) values(?,?,?,?,?,?)");
			pst.setString(1, name);
			pst.setString(2, username);
			pst.setString(3, email);
			pst.setString(4, mobile);
			pst.setString(5, password);
			pst.setString(6, user_address);

			pst.execute();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if (stmt != null)
					stmt.close();
				if (con != null)
					con.close();
			} catch (Exception ex) {
			}
		}
	}

	@Override
	public void setdoctor(String name, String password, String email, String mobile, String address) {
		try {
			Class.forName(IDataBaseConnection.DRIVER);
			con = DriverManager.getConnection(IDataBaseConnection.URL, IDataBaseConnection.USER_NAME,
					IDataBaseConnection.PASSWORD);
			stmt = con.createStatement();
			PreparedStatement pst = con
					.prepareStatement("insert into provider(name,password,email,mobile,address) values(?,?,?,?,?)");
			pst.setString(1, name);
			pst.setString(2, password);
			pst.setString(3, email);
			pst.setString(4, mobile);
			pst.setString(5, address);
			pst.execute();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if (stmt != null)
					stmt.close();
				if (con != null)
					con.close();
			} catch (Exception ex) {
			}
		}

	}

	public void updateDoc(String name, String password, String email, String mobile, String address) {
		try {
			Class.forName(IDataBaseConnection.DRIVER);
			con = DriverManager.getConnection(IDataBaseConnection.URL, IDataBaseConnection.USER_NAME,
					IDataBaseConnection.PASSWORD);
			stmt = con.createStatement();
			String query = "update provider set password='" + password + "', email='" + email + "', mobile='" + mobile
					+ "',address='" + address + "' where name = '" + name + "'";
			stmt.executeUpdate(query);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if (stmt != null)
					stmt.close();
				if (con != null)
					con.close();
			} catch (Exception ex) {
			}
		}
	}

	@Override
	public void deleteDoc(String name) {
		try {
			Class.forName(IDataBaseConnection.DRIVER);
			con = DriverManager.getConnection(IDataBaseConnection.URL, IDataBaseConnection.USER_NAME,
					IDataBaseConnection.PASSWORD);
			stmt = con.createStatement();
			PreparedStatement pst = con.prepareStatement("delete from provider where name = '" + name + "'");

			pst.execute();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if (stmt != null)
					stmt.close();
				if (con != null)
					con.close();
			} catch (Exception ex) {
			}
		}

	}

	@Override
	public void register(String name, String username, String email, String mobile, String password) {
		// TODO Auto-generated method stub

	}

	@Override
	public void adddocdet(String itemid, String itemname, String price, String type, String bookType) {
		try {
			Class.forName(IDataBaseConnection.DRIVER);
			con = DriverManager.getConnection(IDataBaseConnection.URL, IDataBaseConnection.USER_NAME,
					IDataBaseConnection.PASSWORD);
			stmt = con.createStatement();
			PreparedStatement pst = con.prepareStatement(
					"insert into DoctorDetails(doctorid,doctorname,fee,specialization,specializationType) values(?,?,?,?,?)");
			pst.setString(1, itemid);
			pst.setString(2, itemname);
			// pst.setString(3,author);
			pst.setString(3, price);
			// pst.setString(5, publisher);
			pst.setString(4, bookType);
			pst.setString(5, type);
			pst.execute();

		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if (stmt != null)
					stmt.close();
				if (con != null)
					con.close();
			} catch (Exception ex) {
			}
		}

	}

	@Override
	public void viewdoc() {
		try {
			Class.forName(IDataBaseConnection.DRIVER);
			con = DriverManager.getConnection(IDataBaseConnection.URL, IDataBaseConnection.USER_NAME,
					IDataBaseConnection.PASSWORD);
			stmt = con.createStatement();
			PreparedStatement pst = con.prepareStatement("select * from  item");

			pst.execute();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if (stmt != null)
					stmt.close();
				if (con != null)
					con.close();
			} catch (Exception ex) {
			}
		}

	}

	@Override
	public void deletedoc(String id) {
		try {
			Class.forName(IDataBaseConnection.DRIVER);
			con = DriverManager.getConnection(IDataBaseConnection.URL, IDataBaseConnection.USER_NAME,
					IDataBaseConnection.PASSWORD);
			stmt = con.createStatement();
			PreparedStatement pst = con.prepareStatement("delete from  DoctorDetails where doctorid='" + id + "'");

			pst.execute();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if (stmt != null)
					stmt.close();
				if (con != null)
					con.close();
			} catch (Exception ex) {
			}
		}

	}

	@Override
	public void updatedoc(String id, String name, String price, String i, String t) {
		try {
			Class.forName(IDataBaseConnection.DRIVER);
			con = DriverManager.getConnection(IDataBaseConnection.URL, IDataBaseConnection.USER_NAME,
					IDataBaseConnection.PASSWORD);
			stmt = con.createStatement();
			PreparedStatement pst = con
					.prepareStatement("update DoctorDetails set  doctorname='" + name + "',fee='" + price + "',specialization='"
							+ i + "',specializationType ='" + t + "' where doctorid = '" + id + "'");

			pst.execute();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if (stmt != null)
					stmt.close();
				if (con != null)
					con.close();
			} catch (Exception ex) {
			}
		}

	}

	@Override
	public void adddocdetails(String item, String type, String amount, String username, int orderid, String paymenttype, String deliveryType, String custId) {
		try {
			Class.forName(IDataBaseConnection.DRIVER);
			con = DriverManager.getConnection(IDataBaseConnection.URL, IDataBaseConnection.USER_NAME,
					IDataBaseConnection.PASSWORD);
			stmt = con.createStatement();
			LocalDate date = LocalDate.now();
			PreparedStatement pst = con.prepareStatement(
					"insert into appointments(doctorname,type,fee,patientname,appid,appStatus,appDate,paymentType) values(?,?,?,?,?,?,?,?)");

			pst.setString(1, item);
			pst.setString(2, type);
			pst.setString(3, amount);
			pst.setString(4, username);
			pst.setInt(5, orderid);
			pst.setString(6, "pending");
			pst.setString(7, deliveryType);
			pst.setString(8, paymenttype);
			pst.executeUpdate();

		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				if (stmt != null)
					stmt.close();
				if (con != null)
					con.close();
			} catch (Exception ex) {
			}
		}

	}

	@Override
	public void appointStatus(String orderid, String status) {
		try {
			String username = "";
			String deliveryStatus = "";
			Class.forName(IDataBaseConnection.DRIVER);
			con = DriverManager.getConnection(IDataBaseConnection.URL, IDataBaseConnection.USER_NAME,
					IDataBaseConnection.PASSWORD);
			stmt = con.createStatement();
			rs = stmt.executeQuery("SELECT patientname,appStatus FROM appointments where appid='" + orderid + "';");
			if (rs.next()) {
				username = rs.getString("patientname");
				deliveryStatus=rs.getString("appStatus");
			}

			stmt.executeUpdate("delete FROM appstatus where appid='" + orderid + "';");

			PreparedStatement pst = con.prepareStatement("insert into appstatus values(?,?)");
			pst.setString(1, orderid);
			// pst.setString(2,username);
			pst.setString(2, status);
			pst.executeUpdate();
			// pst.close();

				


		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				if (stmt != null)
					stmt.close();
				if (con != null)
					con.close();
			} catch (Exception ex) {
			}
		}

	}

	@Override
	public void updatedeliveryStatus(String orderId, String orderstatus, String type, String date) {
		try {
			Class.forName(IDataBaseConnection.DRIVER);
			con = DriverManager.getConnection(IDataBaseConnection.URL, IDataBaseConnection.USER_NAME,
					IDataBaseConnection.PASSWORD);
			stmt = con.createStatement();
			String query = "update Delivery set deliverytype='" + type + "', status='" + orderstatus
					+ "',deliverydate = '" + date + "' where orderid = " + orderId + "";
			stmt.executeUpdate(query);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if (stmt != null)
					stmt.close();
				if (con != null)
					con.close();
			} catch (Exception ex) {
			}
		}

	}

	

}
