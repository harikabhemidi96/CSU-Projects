package telehealth.controller;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import telehealth.model.DoctorDetails;
import telehealth.model.AptDet;

public class DataDefinitionQueries implements IDataDefinition {
	private static DataDefinitionQueries inst;

	public static DataDefinitionQueries getInst() {
		if (inst == null) {
			inst = new DataDefinitionQueries();
		}
		return inst;
	}

	Connection con = null;
	Statement stmt = null;
	ResultSet rs = null;

	@Override
	public String providerlogin(String userName) {
		String password = null;
		try {
			Class.forName(IDataBaseConnection.DRIVER);
			con = DriverManager.getConnection(IDataBaseConnection.URL, IDataBaseConnection.USER_NAME,
					IDataBaseConnection.PASSWORD);
			stmt = con.createStatement();
			rs = stmt.executeQuery("select password from provider where name = '" + userName + "'");
			while (rs.next()) {
				password = rs.getString(1);
			}

		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if (stmt != null)
					stmt.close();
				if (con != null)
					con.close();
			} catch (Exception ex) {
			}
		}

		return password;
	}

	@Override
	public String login(String userName) {
		String password = null;
		try {
			Class.forName(IDataBaseConnection.DRIVER);
			con = DriverManager.getConnection(IDataBaseConnection.URL, IDataBaseConnection.USER_NAME,
					IDataBaseConnection.PASSWORD);
			stmt = con.createStatement();
			rs = stmt.executeQuery("select password from patient where username='" + userName + "'");
			while (rs.next()) {
				password = rs.getString(1);
			}

		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if (stmt != null)
					stmt.close();
				if (con != null)
					con.close();
			} catch (Exception ex) {
			}
		}

		return password;
	}

	@Override
	public String getproviderAddress(String userName) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getproviderMobileNumber(String userName) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getproviderEmailID(String userName) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public AptDet allApp() {
		AptDet appobj = new AptDet();

		try {
			Class.forName(IDataBaseConnection.DRIVER);
			con = DriverManager.getConnection(IDataBaseConnection.URL, IDataBaseConnection.USER_NAME,
					IDataBaseConnection.PASSWORD);
			stmt = con.createStatement();
			rs = stmt.executeQuery("select * from appointments order by appid");
			while (rs.next()) {
				appobj.name.add(rs.getString(1));
				appobj.type.add(rs.getString(2));
				appobj.amount.add(rs.getString(3));
				appobj.pname.add(rs.getString(4));
				appobj.id.add(rs.getInt(5));
				appobj.astatus.add(rs.getString(6));

			}

		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				if (stmt != null)
					stmt.close();
				if (con != null)
					con.close();
			} catch (Exception ex) {
			}
		}

		return appobj;
	}

	@Override
	public int retrieveNextDocID() {
		int rid = 0;

		try {
			Class.forName(IDataBaseConnection.DRIVER);
			con = DriverManager.getConnection(IDataBaseConnection.URL, IDataBaseConnection.USER_NAME,
					IDataBaseConnection.PASSWORD);
			stmt = con.createStatement();
			rs = stmt.executeQuery("select max(appid)+1 as appid from appointments");
			while (rs.next()) {
				rid = rs.getInt(1);
			}

		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				if (stmt != null)
					stmt.close();
				if (con != null)
					con.close();
			} catch (Exception ex) {
			}
		}

		return rid;
	}

	@Override
	public AptDet allStatus(String username) {

		AptDet obj = new AptDet();

		try {
			Class.forName(IDataBaseConnection.DRIVER);
			con = DriverManager.getConnection(IDataBaseConnection.URL, IDataBaseConnection.USER_NAME,
					IDataBaseConnection.PASSWORD);
			stmt = con.createStatement();
			rs = stmt.executeQuery(
					"select appointments.appid,doctorname, appointments.patientname,os.status,appDate from appointments join appstatus os on os.appid= appointments.appid where appointments.patientname = '"
							+ username + "'");
//            ResultSet status;
//            boolean temp;
			while (rs.next()) {

				obj.id.add(rs.getInt(1));
				obj.name.add(rs.getString(2));
				obj.pname.add(rs.getString(3));

				obj.astatus.add(rs.getString(4));
				obj.aDate.add(rs.getString(5));

			}

		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				if (stmt != null)
					stmt.close();
				if (con != null)
					con.close();
			} catch (Exception ex) {
			}
		}

		return obj;

	}

	@Override
	public String getDocName(String docid) {
		String name = null;
		try {
			Class.forName(IDataBaseConnection.DRIVER);
			con = DriverManager.getConnection(IDataBaseConnection.URL, IDataBaseConnection.USER_NAME,
					IDataBaseConnection.PASSWORD);
			stmt = con.createStatement();
			rs = stmt.executeQuery("select doctorid from DoctorDetails where doctorid = '" + docid + "'");
			while (rs.next()) {
				name = rs.getString(1);
			}

		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if (stmt != null)
					stmt.close();
				if (con != null)
					con.close();
			} catch (Exception ex) {
			}
		}

		return name;

	}

	@Override
	public String getdoctorid() {
		String doctorId = null;
		try {
			Class.forName(IDataBaseConnection.DRIVER);
			con = DriverManager.getConnection(IDataBaseConnection.URL, IDataBaseConnection.USER_NAME,
					IDataBaseConnection.PASSWORD);
			stmt = con.createStatement();
			rs = stmt.executeQuery("select doctorid from DoctorDetails ");
			while (rs.next()) {
				doctorId = rs.getString(1);
			}

		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if (stmt != null)
					stmt.close();
				if (con != null)
					con.close();
			} catch (Exception ex) {
			}
		}

		return doctorId;
	}



	@Override
	public ArrayList<DoctorDetails> viewallDoc() {
		return null;

	}

	@Override
	public DoctorDetails viewallDocbasedonName(String docName) {
		// TODO Auto-generated method stub
		DoctorDetails obj = new DoctorDetails();

		try {
			Class.forName(IDataBaseConnection.DRIVER);
			con = DriverManager.getConnection(IDataBaseConnection.URL, IDataBaseConnection.USER_NAME,
					IDataBaseConnection.PASSWORD);
			stmt = con.createStatement();
			rs = stmt.executeQuery("Select * From telehealthdb.DoctorDetails where doctorname='" + docName + "'");
			while (rs.next()) {
				//Item item = new Item();
				obj.doctorid = rs.getString(1);
				obj.doctorname = rs.getString(2);
				obj.fee = rs.getString(3);
				obj.specialization = rs.getString(4);

			}

		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				if (stmt != null)
					stmt.close();
				if (con != null)
					con.close();
			} catch (Exception ex) {
			}
		}

		return obj;

	}



	@Override
	public String getAppointmentStatusByID(String id) {
		String orderId = null;
		try {
			Class.forName(IDataBaseConnection.DRIVER);
			con = DriverManager.getConnection(IDataBaseConnection.URL, IDataBaseConnection.USER_NAME,
					IDataBaseConnection.PASSWORD);
			stmt = con.createStatement();
			rs = stmt.executeQuery("select appid from appstatus where appid='" + id + "'");
			while (rs.next()) {
				orderId = rs.getString(1);
			}

		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if (stmt != null)
					stmt.close();
				if (con != null)
					con.close();
			} catch (Exception ex) {
			}
		}

		return orderId;
	}

	

}
