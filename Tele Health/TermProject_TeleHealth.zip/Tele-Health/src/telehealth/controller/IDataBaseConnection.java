package telehealth.controller;

public interface IDataBaseConnection {
    
    public static final String USER_NAME = "root";
    public static final String PASSWORD = "root";


    public static final String URL = "jdbc:mysql://localhost:3306/telehealthdb";

    public static final String DRIVER = "com.mysql.cj.jdbc.Driver";
    
    
}
