package telehealth.controller;

public interface IDataManipulation {
    
    public void register(String name, String username, String email, String mobile, String password,String user_address );

	public void setdoctor(String name, String password, String email, String mobile, String address);

	public void updateDoc(String name, String password, String email, String mobile, String address);
	public void deleteDoc(String name);

	 public void register(String name, String username, String email, String mobile, String password);

	    //public void employeeRegister(String username, String password, String name, String mobile, String email);

	    public void adddocdet(String itemid, String itemname,String price, String typeOfitem,String itemtype);

	    public void viewdoc();

	    public void deletedoc(String itemid);

	    public void updatedoc(String itemid, String itemname, String price, String typeOfitem,String itemtype);

	   // public void updateEmployee(String name, String password, String email, String mobile, String address);

	    

	    //public void application(String bankname, String type, String amount,int applicationid,String username);
     
	    public void adddocdetails(String itemname, String type, String amount,String username,int orderid,String paymenttype, String deliveryType,String custId);

	    public void appointStatus(String orderid, String status);

		//public DeliveryObj updatedeliveryStatus();

		public void updatedeliveryStatus(String orderId, String orderstatus, String type,String date);

		

}
