package telehealth.controller;

import java.util.ArrayList;

public class AppStatus {

	public ArrayList<String> id = new ArrayList();
	public ArrayList<String> pname = new ArrayList();
	public ArrayList<String> status = new ArrayList();

}






