package telehealth.controller;

import java.util.ArrayList;
import telehealth.model.DoctorDetails;
import telehealth.model.AptDet;

public interface IDataDefinition {

	String login(String userName);

	AptDet allStatus(String username);

	String providerlogin(String userName);

	String getDocName(String bookid);

	String getdoctorid();

	int retrieveNextDocID();

	AptDet allApp();

	String getAppointmentStatusByID(String id);

	String getproviderAddress(String userName);

	String getproviderMobileNumber(String userName);

	String getproviderEmailID(String userName);

	ArrayList<DoctorDetails> viewallDoc();

	public DoctorDetails viewallDocbasedonName(String itemName);

}
