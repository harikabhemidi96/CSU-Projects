
package telehealth.view;

import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.table.DefaultTableModel;

import telehealth.model.Appointments;
import telehealth.model.KeyValue;
import telehealth.model.AptDet;
import telehealth.model.DermatologyApt;
import telehealth.model.EndoscopyApt;
import telehealth.model.InternalMedicineApt;
import telehealth.model.PatientDetails;
import telehealth.model.PedatricsApt;
import telehealth.model.PsychiatryApt;

import javax.swing.JLabel;
import javax.swing.GroupLayout.Alignment;

import java.awt.BorderLayout;
import java.awt.Color;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Observable;
import java.util.Observer;

import javax.swing.GroupLayout;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.JComboBox;
import javax.swing.ScrollPaneConstants;

public class AvailableAppDates extends javax.swing.JFrame implements Observer {

	private static final long serialVersionUID = 1L;
	PatientDetails customer = new PatientDetails();
    AptDet appobj;
    Appointments app = new Appointments();
    int i;
    private List<Observable> observables;
	 public static ArrayList<String> list=new ArrayList<String>();
	 public static ArrayList<KeyValue> list1=new ArrayList<KeyValue>();

    public AvailableAppDates(List<Observable> observable) {
    	//getContentPane().setBackground(new Color(173, 216, 230));
    	try {
		    final java.awt.Image backgroundImage = javax.imageio.ImageIO.read(new File("C:\\images\\img1.jpg"));
		    setContentPane(new JPanel(new BorderLayout()) {
		        @Override public void paintComponent(java.awt.Graphics g) {
		            g.drawImage(backgroundImage, 0, 0, null);
		        }
		    });
		} catch (IOException e) {
		    throw new RuntimeException(e);
		}
    	initComponents();
    	this.observables=new ArrayList<Observable>();
        for (Observable observable1 : observable) {
              this.observables.add(observable1);
              observable1.addObserver(this);
         }
        
        
                String[] cols = {"Speciality","AvailableAppointments"};
        DefaultTableModel table = new DefaultTableModel(cols,0);
        jTable1.setModel(table);
            
      
        
    }

    @SuppressWarnings({ "unchecked", "serial" })                      
    private void initComponents() {
        jScrollPane1 = new javax.swing.JScrollPane(); 
        jScrollPane1.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
        jScrollPane1.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_ALWAYS);
        jScrollPane1.setForeground(Color.GRAY);
        jTable1 = new javax.swing.JTable();
        jLabel1 = new javax.swing.JLabel();
        submit = new javax.swing.JButton();
        submit.setBackground(Color.GRAY);
        submit.setForeground(Color.WHITE);
        back = new javax.swing.JButton();
        back.setForeground(Color.WHITE);
        back.setBackground(Color.GRAY);

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(Color.LIGHT_GRAY);

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "App id", "Doctor name", "Speciality", "Fee", "PatientName"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, true, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(jTable1);

        jLabel1.setFont(new java.awt.Font("Times New Roman", 3, 24)); 
        jLabel1.setForeground(Color.GRAY);
        jLabel1.setText("All Appointments");

        submit.setText("submit");
        submit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                submitActionPerformed(evt);
            }
        });

        back.setText("Back");
        back.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                backActionPerformed(evt);
            }
        });
//        String[] orderList = {
//        	    "Ordered", "Packed", "Shipped", "Out for Delivery",
//        	    "Delivered"
//        	  };
        
        String[] orderList = {
        	    "Booked", "Not Available","Pending"};
        
        int count = 0;
	       

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        layout.setHorizontalGroup(
        	layout.createParallelGroup(Alignment.TRAILING)
        		.addGroup(layout.createSequentialGroup()
        			.addGroup(layout.createParallelGroup(Alignment.LEADING)
        				.addGroup(layout.createSequentialGroup()
        					.addGap(82)
        					.addComponent(jLabel1, GroupLayout.PREFERRED_SIZE, 422, GroupLayout.PREFERRED_SIZE))
        				.addGroup(layout.createSequentialGroup()
        					.addGap(39)
        					.addComponent(jScrollPane1, GroupLayout.PREFERRED_SIZE, 358, GroupLayout.PREFERRED_SIZE)))
        			.addContainerGap(603, Short.MAX_VALUE))
        		.addGroup(layout.createSequentialGroup()
        			.addGap(0, 542, Short.MAX_VALUE)
        			.addGroup(layout.createParallelGroup(Alignment.TRAILING)
        				.addGroup(layout.createSequentialGroup()
        					.addComponent(submit, GroupLayout.PREFERRED_SIZE, 151, GroupLayout.PREFERRED_SIZE)
        					.addGap(339))
        				.addGroup(layout.createSequentialGroup()
        					.addComponent(back, GroupLayout.PREFERRED_SIZE, 102, GroupLayout.PREFERRED_SIZE)
        					.addGap(176))))
        );
        layout.setVerticalGroup(
        	layout.createParallelGroup(Alignment.LEADING)
        		.addGroup(layout.createSequentialGroup()
        			.addContainerGap(82, Short.MAX_VALUE)
        			.addComponent(back)
        			.addPreferredGap(ComponentPlacement.RELATED)
        			.addComponent(jLabel1, GroupLayout.PREFERRED_SIZE, 59, GroupLayout.PREFERRED_SIZE)
        			.addGap(29)
        			.addComponent(jScrollPane1, GroupLayout.PREFERRED_SIZE, 102, GroupLayout.PREFERRED_SIZE)
        			.addGap(131)
        			.addComponent(submit, GroupLayout.PREFERRED_SIZE, 45, GroupLayout.PREFERRED_SIZE)
        			.addGap(19))
        );
        getContentPane().setLayout(layout);

        pack();
    }                       

    private void submitActionPerformed(java.awt.event.ActionEvent evt) {   
    	for (Observable obs : observables) {
			  if(obs instanceof InternalMedicineApt) {
	        	InternalMedicineApt cobs=(InternalMedicineApt)obs;
	        	cobs.aptAvailable();}
			}
    	for (Observable obs : observables) {
			  if(obs instanceof PsychiatryApt) {
	        	PsychiatryApt cobs=(PsychiatryApt)obs;
	        	cobs.aptAvailable();
			}}
    	 for (Observable obs : observables) {
			  if(obs instanceof EndoscopyApt) {
	        	EndoscopyApt cobs=(EndoscopyApt)obs;
	        	cobs.aptAvailable();
			}}
    	 for (Observable obs : observables) {
			  if(obs instanceof DermatologyApt) {
	        	DermatologyApt cobs=(DermatologyApt)obs;
	        	cobs.aptAvailable();
			}}
    	 for (Observable obs : observables) {
			  if(obs instanceof PedatricsApt) {
       	PedatricsApt cobs=(PedatricsApt)obs;
       	cobs.aptAvailable();
		}}
    	 String[] cols = {"Speciality","AvailableAppointments"};
         DefaultTableModel table = new DefaultTableModel(cols,0);
         jTable1.setModel(table);
    	  for(i = 0;i<list1.size();i++){
              Object[] data = {list1.get(i).getKey(),list1.get(i).getValue()};
                 
              table.addRow(data);
          }
        }
                                         

    private void backActionPerformed(java.awt.event.ActionEvent evt) {                                     
     HomePageProvider home = new HomePageProvider();
     home.setVisible(true);
     this.setVisible(false);
    }                                    

    public static void main(String args[]) {
         try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(AvailableAppDates.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(AvailableAppDates.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(AvailableAppDates.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(AvailableAppDates.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
       

       
    }
                 
    private javax.swing.JButton back;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JButton submit;

	@Override
	public void update(Observable obs, Object arg) {
		// TODO Auto-generated method stub
		if(obs instanceof InternalMedicineApt){
			 InternalMedicineApt im=(InternalMedicineApt)obs;
			 KeyValue kv=new KeyValue();
			 kv.setKey("internalMedicine");
			 kv.setValue(im.getcount());
			 list1.add(kv);
			 
	        }
	        if(obs instanceof DermatologyApt){
	           DermatologyApt derm=(DermatologyApt) obs;
	          
	           KeyValue kv=new KeyValue();
				 kv.setKey("Dermatology");
				 kv.setValue(derm.getcount());
				 list1.add(kv);
	        }
	        if(obs instanceof PsychiatryApt){
	           PsychiatryApt p=(PsychiatryApt) obs;
	           KeyValue kv=new KeyValue();
				 kv.setKey("Psychiatry");
				 kv.setValue(p.getcount());
				 list1.add(kv);
	           
	        }
	        if(obs instanceof EndoscopyApt){
	        	EndoscopyApt e=(EndoscopyApt) obs;
	        	 KeyValue kv=new KeyValue();
				 kv.setKey("Endoscopy");
				 kv.setValue(e.getcount());
				 list1.add(kv);
		        }
	        if(obs instanceof PedatricsApt){
	        	PedatricsApt p=(PedatricsApt) obs;
	        	 KeyValue kv=new KeyValue();
				 kv.setKey("Pedatrics");
				 kv.setValue(p.getcount());
				 list1.add(kv);
		        }
	}
	
}
