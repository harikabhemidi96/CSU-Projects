package telehealth.view;

import java.awt.BorderLayout;
import java.awt.Color;
import java.util.ArrayList;

import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.table.DefaultTableModel;

import telehealth.model.AppointmentData;
import telehealth.model.Appointments;
import telehealth.model.DoctorConfirmed;
import telehealth.model.DoctorDetails;
import telehealth.model.KeyValue;
import telehealth.model.PatientDetails;

import javax.swing.GroupLayout.Alignment;
import javax.swing.GroupLayout;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.JLabel;
import javax.swing.JComboBox;
import javax.swing.JCheckBox;
import javax.swing.JRadioButton;
import java.io.File;
import java.io.IOException;
import javax.swing.JToggleButton;


public class AppointmentDetails extends javax.swing.JFrame {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	PatientDetails patient = new PatientDetails();
	DoctorDetails doc = new DoctorDetails();
	Appointments app = new Appointments();
	int appid = app.getNextAppID();

	int i;
	String username;

	public AppointmentDetails(String username) {

		try {
		    final java.awt.Image backgroundImage = javax.imageio.ImageIO.read(new File("C:\\images\\img1.jpg"));
		    setContentPane(new JPanel(new BorderLayout()) {
		        @Override public void paintComponent(java.awt.Graphics g) {
		            g.drawImage(backgroundImage, 0, 0, null);
		        }
		    });
		} catch (IOException e) {
		    throw new RuntimeException(e);
		}
		initComponents();

		String[] cols = { "Doctor Name", "Specialization", "Fee"
				+ ""
				+ ""
				+ ""
				+ ""
				+ ""
				+ ""
				+ "" };
		DefaultTableModel table = new DefaultTableModel(cols, 0);

		this.username = username;
	}

	@SuppressWarnings("unchecked")
	// <editor-fold defaultstate="collapsed" desc="Generated Code">
	private void initComponents() {

		jLabel1 = new javax.swing.JLabel();
		jLabel1.setForeground(Color.GRAY);
		names = new javax.swing.JLabel();
		names.setForeground(Color.GRAY);
		appBooked = new javax.swing.JButton();
		appBooked.setBackground(Color.GRAY);
		appBooked.setForeground(Color.WHITE);
		jButton2 = new javax.swing.JButton();
		jButton2.setBackground(Color.GRAY);
		jButton2.setForeground(Color.WHITE);
		Fee = new JLabel("Date");
		Fee.setForeground(Color.GRAY);
		comb = new JComboBox();
		int count3 = 0;
		String[] categories5 = { "4/22/2022", "5/22/2022", "6/22/2022" };
		for (int i = 0; i < categories5.length; i++)
			comb.addItem(categories5[count3++]);
		setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
		Other = new JLabel("Other");
		Other.setForeground(Color.GRAY);
		nurse = new JToggleButton("Nurse");
		nurse.setForeground(Color.GRAY);
		therapy = new JToggleButton("Therapy");
		therapy.setForeground(Color.GRAY);

		lblNewLabel_1 = new JLabel("Type of Appointment");
		lblNewLabel_1.setForeground(Color.GRAY);

		inPerson = new JToggleButton("InPerson");
		inPerson.setForeground(Color.GRAY);

		vir = new JToggleButton("Virtual");
		vir.setForeground(Color.GRAY);

		emerge = new JToggleButton("Emergency");
		emerge.setForeground(Color.GRAY);

		lblNewLabel_2 = new JLabel("No of Visit");
		lblNewLabel_2.setForeground(Color.GRAY);

		first = new JToggleButton("First");
		first.setForeground(Color.GRAY);

		second = new JToggleButton("Second");
		second.setForeground(Color.GRAY);

		montly = new JToggleButton("Monthly");
		montly.setForeground(Color.GRAY);
		aptdd = new ArrayList<AppointmentData>();
		jLabel1.setFont(new java.awt.Font("Times New Roman", 3, 18)); // NOI18N
		jLabel1.setText("Book An Appointment");

		names.setText("Doctor");

		appBooked.setText("Add Details");
		appBooked.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				placeOrderActionPerformed(evt);
			}
		});

		jButton2.setText("Back");
		jButton2.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				jButton2ActionPerformed(evt);
			}
		});

		JLabel lblPaymentMode = new JLabel();
		lblPaymentMode.setForeground(Color.GRAY);
		lblPaymentMode.setText("Payment Mode");
		// xtPaymenttype.setText("paymenttype");

		comboBox = new JComboBox();
		int count = 0;
		String[] casht ={ "Cash", "Credit", "Debit" };
		for (int i = 0; i < casht.length; i++)
			comboBox.addItem(casht[count++]);

		comboBox_1 = new JComboBox();
		int count1 = 0;
		String[] doc = { "Doctor1", "Doctor2", "Doctor3","Doctor4","Doctor5" };
		for (int i = 0; i < doc.length; i++)
			comboBox_1.addItem(doc[count1++]);

		javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
		layout.setHorizontalGroup(
			layout.createParallelGroup(Alignment.LEADING)
				.addGroup(layout.createSequentialGroup()
					.addGroup(layout.createParallelGroup(Alignment.LEADING, false)
						.addGroup(layout.createSequentialGroup()
							.addGap(78)
							.addComponent(jLabel1, GroupLayout.PREFERRED_SIZE, 362, GroupLayout.PREFERRED_SIZE))
						.addGroup(layout.createSequentialGroup()
							.addGap(48)
							.addGroup(layout.createParallelGroup(Alignment.LEADING)
								.addComponent(names, GroupLayout.PREFERRED_SIZE, 86, GroupLayout.PREFERRED_SIZE)
								.addComponent(Fee, GroupLayout.PREFERRED_SIZE, 65, GroupLayout.PREFERRED_SIZE)
								.addComponent(lblNewLabel_1)
								.addComponent(Other)
								.addComponent(lblNewLabel_2)
								.addComponent(lblPaymentMode, GroupLayout.PREFERRED_SIZE, 86, GroupLayout.PREFERRED_SIZE)
								.addComponent(appBooked, GroupLayout.PREFERRED_SIZE, 132, GroupLayout.PREFERRED_SIZE))
							.addGap(96)
							.addGroup(layout.createParallelGroup(Alignment.LEADING)
								.addComponent(comboBox, 0, 195, Short.MAX_VALUE)
								.addComponent(nurse)
								.addComponent(first)
								.addComponent(inPerson)
								.addComponent(comb, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
								.addComponent(comboBox_1, 0, 191, Short.MAX_VALUE)
								.addComponent(second)
								.addComponent(montly)
								.addComponent(vir)
								.addComponent(emerge)
								.addComponent(therapy))))
					.addGap(5)
					.addComponent(jButton2, GroupLayout.PREFERRED_SIZE, 144, GroupLayout.PREFERRED_SIZE)
					.addContainerGap(551, Short.MAX_VALUE))
		);
		layout.setVerticalGroup(
			layout.createParallelGroup(Alignment.LEADING)
				.addGroup(layout.createSequentialGroup()
					.addGap(19)
					.addGroup(layout.createParallelGroup(Alignment.LEADING)
						.addGroup(layout.createSequentialGroup()
							.addComponent(jLabel1, GroupLayout.PREFERRED_SIZE, 35, GroupLayout.PREFERRED_SIZE)
							.addGap(30)
							.addGroup(layout.createParallelGroup(Alignment.BASELINE)
								.addComponent(names, GroupLayout.PREFERRED_SIZE, 24, GroupLayout.PREFERRED_SIZE)
								.addComponent(comboBox_1, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
							.addPreferredGap(ComponentPlacement.UNRELATED)
							.addGroup(layout.createParallelGroup(Alignment.BASELINE)
								.addComponent(Fee)
								.addComponent(comb, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
							.addPreferredGap(ComponentPlacement.RELATED)
							.addGroup(layout.createParallelGroup(Alignment.LEADING)
								.addComponent(lblNewLabel_1)
								.addComponent(inPerson))
							.addPreferredGap(ComponentPlacement.UNRELATED)
							.addComponent(vir)
							.addPreferredGap(ComponentPlacement.UNRELATED)
							.addComponent(emerge)
							.addGap(52)
							.addGroup(layout.createParallelGroup(Alignment.TRAILING)
								.addComponent(nurse)
								.addComponent(Other))
							.addPreferredGap(ComponentPlacement.UNRELATED)
							.addComponent(therapy)
							.addGap(39)
							.addGroup(layout.createParallelGroup(Alignment.LEADING)
								.addComponent(lblNewLabel_2)
								.addComponent(first)))
						.addComponent(jButton2, GroupLayout.PREFERRED_SIZE, 47, GroupLayout.PREFERRED_SIZE))
					.addPreferredGap(ComponentPlacement.UNRELATED)
					.addComponent(second)
					.addPreferredGap(ComponentPlacement.UNRELATED)
					.addComponent(montly)
					.addGap(50)
					.addGroup(layout.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblPaymentMode, GroupLayout.PREFERRED_SIZE, 20, GroupLayout.PREFERRED_SIZE)
						.addComponent(comboBox, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(35)
					.addComponent(appBooked, GroupLayout.DEFAULT_SIZE, 47, Short.MAX_VALUE)
					.addGap(156))
		);
		getContentPane().setLayout(layout);

		pack();
	}// </editor-fold>

	private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {
		PatientLogin home = new PatientLogin(username);
		home.setVisible(true);
		this.setVisible(false);
	}

	private void placeOrderActionPerformed(java.awt.event.ActionEvent evt) {

		DoctorConfirmed doc = new DoctorConfirmed();
		doc.setDocName((String) comboBox_1.getSelectedItem());
		
		doc.setDate((String)comb.getSelectedItem());
		if (nurse.isSelected()) {
			
			doc.setserviceType("2");
			
		}

		if (therapy.isSelected()) {
			doc.setserviceType("1");
		}

		if (inPerson.isSelected()) {
			doc.setInPerson(true);
		}

		if (vir.isSelected()) {
			
			doc.setIsVirtual(true);
		}

		if (emerge.isSelected()) {
			doc.setserviceType("1");
		}

		if (first.isSelected()) {
			doc.setaType("1");
		}

		if (second.isSelected()) {
			doc.setaType("2");
		}

		if (montly.isSelected()) {
			doc.setaType("3");
		}


		aptdd.add(app.addApptolist(doc, appid));
		for (AppointmentData aptt : aptdd) {
			aptt.patName=username;
		}
		JOptionPane.showMessageDialog(this, "Appointment Added");
		ViewAppointDetails vp=new ViewAppointDetails(username, aptdd);
		vp.setVisible(true);

	}

	private void addItemKey(String A, String B, ArrayList<KeyValue> Addons) {
		KeyValue keyvalue = new KeyValue();
		keyvalue.setKey(A);
		keyvalue.setValue(B);
	}

	// Variables declaration - do not modify
	private javax.swing.JLabel names;
	private javax.swing.JButton appBooked;
	private javax.swing.JButton jButton2;
	private javax.swing.JLabel jLabel1;
	private javax.swing.JComboBox comboBox;
	private JComboBox comboBox_1;
	private JLabel Fee;

	private JComboBox comb;

	private JLabel Other;

	private JToggleButton nurse;

	private JToggleButton therapy;

	private JLabel lblNewLabel_1;

	private JToggleButton inPerson;

	private JToggleButton vir;

	private JToggleButton emerge;

	private JLabel lblNewLabel_2;

	private JToggleButton first;

	private JToggleButton second;

	private JToggleButton montly;
	private ArrayList<AppointmentData> aptdd;
}
