package telehealth.view;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import javax.swing.SwingConstants;

import telehealth.model.ProviderDetails;
import telehealth.model.PatientDetails;

import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JFrame;

import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import java.awt.event.ActionEvent;

public class AdminUI extends javax.swing.JFrame {
	// String user;
	ProviderDetails seller = new ProviderDetails();
	// String user_name;
	PatientDetails user = new PatientDetails();

	public AdminUI() {
		//getContentPane().setBackground(new Color(173, 216, 230));
		try {
		    final java.awt.Image backgroundImage = javax.imageio.ImageIO.read(new File("C:\\images\\img1.jpg"));
		    setContentPane(new JPanel(new BorderLayout()) {
		        @Override public void paintComponent(java.awt.Graphics g) {
		            g.drawImage(backgroundImage, 0, 0, null);
		        }
		    });
		} catch (IOException e) {
		    throw new RuntimeException(e);
		}
		initComponents();
	}

	private void initComponents() {
		setLocationByPlatform(true);
		setFont(new Font("Arial Unicode MS", Font.BOLD | Font.ITALIC, 17));
		setTitle("Tele-Health");
		setBounds(100, 100, 703, 494);
		getContentPane().setLayout(null);
		setAlwaysOnTop(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setPreferredSize(new Dimension(800, 600));

		JLabel lblLoginHere = new JLabel("Login Here");
		lblLoginHere.setForeground(Color.GRAY);
		lblLoginHere.setHorizontalAlignment(SwingConstants.CENTER);
		lblLoginHere.setFont(new Font("Trebuchet MS", Font.PLAIN, 18));
		setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
		lblLoginHere.setBounds(51, 44, 272, 21);
		getContentPane().add(lblLoginHere);

		JLabel lblNewLabel = new JLabel("User Name");
		lblNewLabel.setForeground(Color.GRAY);
		lblNewLabel.setBounds(97, 117, 64, 14);
		getContentPane().add(lblNewLabel);

		JLabel lblNewLabel_1 = new JLabel("Password");
		lblNewLabel_1.setForeground(Color.GRAY);
		lblNewLabel_1.setBounds(97, 151, 100, 14);
		getContentPane().add(lblNewLabel_1);

		username = new JTextField();
		username.setBounds(203, 114, 155, 20);
		getContentPane().add(username);
		username.setColumns(10);
		username.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				usernameActionPerformed(evt);
			}
		});

		password = new JTextField();
		password.setBounds(203, 148, 155, 20);
		getContentPane().add(password);
		password.setColumns(10);

		password.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				passwordActionPerformed(evt);
			}
		});

		JButton btnNewButton = new JButton("Login");
		btnNewButton.setBackground(Color.GRAY);
		btnNewButton.setForeground(Color.WHITE);
		btnNewButton.setBounds(165, 203, 89, 23);
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				LoginActionPerformed(e);
			}

		});
		getContentPane().add(btnNewButton);

		JButton btnNewButton_1 = new JButton("Back");
		btnNewButton_1.setBackground(Color.GRAY);
		btnNewButton_1.setForeground(Color.WHITE);
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				backActionPerformed(e);
			}
		});
		btnNewButton_1.setBounds(335, 11, 89, 23);
		getContentPane().add(btnNewButton_1);
		getContentPane().setBackground(new Color(173, 216, 230));
	}

	private static final long serialVersionUID = 1L;

	private JTextField username;
	private JTextField password;

	private void LoginActionPerformed(ActionEvent e) {
		if (username.getText().equals("") || password.getText().equals("")) {
			JOptionPane.showMessageDialog(this, "Enter valid username or password");
		}
	
		if (username.getText().equals("admin") && password.getText().equals("admin")) {
			AdminPage adminpage = new AdminPage();
			adminpage.setVisible(true);
			this.setVisible(false);
		}
		
		else {
			JOptionPane.showMessageDialog(this, "Enter valid username or password");
		}
	}

	private void backActionPerformed(ActionEvent e) {
		MainHome home = new MainHome();
		home.pack();
		home.setLocationRelativeTo(null);
		home.setVisible(true);
		this.setVisible(false);
	}

	private void usernameActionPerformed(java.awt.event.ActionEvent evt) {
		// TODO add your handling code here:
	}

	private void passwordActionPerformed(java.awt.event.ActionEvent evt) {
		// TODO add your handling code here:
	}

}
