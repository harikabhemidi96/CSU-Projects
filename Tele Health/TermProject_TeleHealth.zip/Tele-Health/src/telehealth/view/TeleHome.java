package telehealth.view;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

import java.awt.BorderLayout;
import java.awt.Font;
import java.awt.Color;
import java.awt.Dimension;

import javax.swing.SwingConstants;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.BoxLayout;
import java.awt.GridBagLayout;
import java.awt.GridBagConstraints;
import java.awt.FlowLayout;
import javax.swing.JButton;
import java.awt.Window.Type;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import java.awt.event.ActionEvent;
import java.awt.SystemColor;
import javax.swing.UIManager;
import java.awt.Toolkit;
import javax.swing.ImageIcon;

@SuppressWarnings("serial")
public class TeleHome extends javax.swing.JFrame {
	
	LoginUI login;
    PatientUI registration;
    
	

	public TeleHome() {
		//getContentPane().setBackground(new Color(173, 216, 230));
			try {
				final java.awt.Image backgroundImage = javax.imageio.ImageIO.read(new File("C:\\images\\img1.jpg"));
			    setContentPane(new JPanel(new BorderLayout()) {
			        @Override public void paintComponent(java.awt.Graphics g) {
			            g.drawImage(backgroundImage, 0, 0, null);
			        }
			    });
			} catch (IOException e) {
			    throw new RuntimeException(e);
			}

		
		initComponents();
	}

@SuppressWarnings("unchecked")
private void initComponents() {
	 //JFrame frmBookStore = new JFrame();
		
		setLocationByPlatform( true );
		setFont(new Font("Microsoft YaHei UI", Font.BOLD, 19));
		setTitle("Tele-Health");
		setBounds(100, 100, 703, 494);
		getContentPane().setLayout(null);
		setAlwaysOnTop (true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setPreferredSize(new Dimension(800, 600));
      // setBackground(Color.RED);
		JButton loginButton = new JButton("User Login");
		loginButton.setForeground(Color.WHITE);
		loginButton.setBackground(Color.GRAY);
		loginButton.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
				 loginActionPerformed(e);	
			}	
		});
	
		loginButton.setBounds(104, 358, 149, 56);
		getContentPane().add(loginButton, BorderLayout.CENTER);
		
		JButton loginButton1 = new JButton("Admin Login");
		loginButton1.setForeground(Color.WHITE);
		loginButton1.setBackground(Color.GRAY);
		loginButton1.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
			loginAdminActionPerformed(e);	
			}	
		});
	
		loginButton1.setBounds(104, 192, 149, 56);
		getContentPane().add(loginButton1);
		
		JButton loginButton2 = new JButton("Provider Login");
		loginButton2.setForeground(Color.WHITE);
		loginButton2.setBackground(Color.GRAY);
		loginButton2.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
			loginRestActionPerformed(e);	
			}	
		});
	
		loginButton2.setBounds(104, 279, 149, 56);
		getContentPane().add(loginButton2);
		
		
		JLabel header = new JLabel("Tele-Health");
		header.setBackground(Color.GRAY);
    	header.setBounds(185, 44, 295, 35);
		header.setHorizontalAlignment(SwingConstants.CENTER);
		header.setForeground(Color.GRAY);
		header.setFont(new Font("Tahoma", Font.PLAIN, 29));
		getContentPane().add(header);
		
		JButton registerButton = new JButton("Sign up");
		registerButton.setForeground(Color.WHITE);
		registerButton.setBackground(Color.GRAY);
		registerButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				registerActionPerformed(e);
	}
		});
		registerButton.setBounds(350, 192, 155, 56);
		getContentPane().add(registerButton, BorderLayout.CENTER);
		pack();
		setLocationRelativeTo(null);
		setVisible(true);
	
	}
	

	private void loginActionPerformed(ActionEvent e) {
		LoginUI login = new LoginUI();
        login.setVisible(true);
        this.setVisible(false);
		
	}
	
	private void loginAdminActionPerformed(ActionEvent e) {
		AdminUI adminUI = new AdminUI();
		adminUI.setVisible(true);
        this.setVisible(false);
		
	}
	
	private void loginRestActionPerformed(ActionEvent e) {
		HomePageProviderUI restaurantUI = new HomePageProviderUI();
		restaurantUI.setVisible(true);
        this.setVisible(false);
		
	}
	
	private void registerActionPerformed(ActionEvent e) {
		 PatientUI reg = new PatientUI();
         reg.setVisible(true);
         this.setVisible(false);
		
	}
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					TeleHome window = new TeleHome();
					
					window.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	
	 

}
