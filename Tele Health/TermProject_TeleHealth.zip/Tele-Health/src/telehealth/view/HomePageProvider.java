package telehealth.view;
import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.GroupLayout.Alignment;
import javax.swing.GroupLayout;
import javax.swing.LayoutStyle.ComponentPlacement;

import telehealth.model.DermatologyApt;
import telehealth.model.EndoscopyApt;
import telehealth.model.InternalMedicineApt;
import telehealth.model.PatientDetails;
import telehealth.model.PedatricsApt;
import telehealth.model.PsychiatryApt;

import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Observable;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.Font;

public class HomePageProvider extends javax.swing.JFrame {
 
	private static final long serialVersionUID = 1L;
	PatientDetails customer = new PatientDetails();

    public HomePageProvider() {
    	//getContentPane().setBackground(new Color(173, 216, 230));
    	try {
		    final java.awt.Image backgroundImage = javax.imageio.ImageIO.read(new File("C:\\images\\img1.jpg"));
		    setContentPane(new JPanel(new BorderLayout()) {
		        @Override public void paintComponent(java.awt.Graphics g) {
		            g.drawImage(backgroundImage, 0, 0, null);
		        }
		    });
		} catch (IOException e) {
		    throw new RuntimeException(e);
		}
    	initComponents();
    }


    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        Heading = new javax.swing.JLabel();
        manageOrders = new javax.swing.JButton();
        manageOrders.setFont(new Font("Tahoma", Font.PLAIN, 11));
        Logout = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        Heading.setFont(new java.awt.Font("Times New Roman", 3, 24));
        Heading.setForeground(Color.DARK_GRAY);
        Heading.setText("Provider");

        manageOrders.setText("View Appointments");
        manageOrders.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                manageOrdersActionPerformed(evt);
            }
        });

        Logout.setText("SignOff");
        Logout.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                LogoutActionPerformed(evt);
            }
        });
        
        JButton addItem = new JButton("View Doctor");
        addItem.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		AddItemActionPerformed(e);
        	}
        });
        
        btnNewButton = new JButton("Appointment");
        btnNewButton.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		List<Observable> ob=new ArrayList<Observable>();
        		ob.add(new InternalMedicineApt());
        		ob.add(new DermatologyApt());
        		ob.add(new PsychiatryApt());
        		ob.add(new PedatricsApt());
        		ob.add(new EndoscopyApt());
        		AvailableAppDates latest=new AvailableAppDates(ob);
        		latest.setVisible(true);
        	}
        });
        

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        layout.setHorizontalGroup(
        	layout.createParallelGroup(Alignment.LEADING)
        		.addGroup(layout.createSequentialGroup()
        			.addGroup(layout.createParallelGroup(Alignment.LEADING)
        				.addGroup(layout.createSequentialGroup()
        					.addGap(90)
        					.addComponent(Heading, GroupLayout.PREFERRED_SIZE, 442, GroupLayout.PREFERRED_SIZE)
        					.addPreferredGap(ComponentPlacement.RELATED, 45, Short.MAX_VALUE)
        					.addComponent(btnNewButton)
        					.addPreferredGap(ComponentPlacement.RELATED))
        				.addGroup(layout.createSequentialGroup()
        					.addGap(123)
        					.addComponent(manageOrders)
        					.addGap(31)
        					.addComponent(addItem, GroupLayout.DEFAULT_SIZE, 393, Short.MAX_VALUE)))
        			.addGap(85)
        			.addComponent(Logout, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        			.addGap(256))
        );
        layout.setVerticalGroup(
        	layout.createParallelGroup(Alignment.LEADING)
        		.addGroup(layout.createSequentialGroup()
        			.addGap(41)
        			.addGroup(layout.createParallelGroup(Alignment.LEADING)
        				.addGroup(layout.createParallelGroup(Alignment.TRAILING)
        					.addComponent(Heading)
        					.addComponent(Logout))
        				.addComponent(btnNewButton))
        			.addGap(53)
        			.addGroup(layout.createParallelGroup(Alignment.LEADING)
        				.addComponent(addItem, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        				.addComponent(manageOrders, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        			.addGap(305))
        );
        getContentPane().setLayout(layout);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void LogoutActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_LogoutActionPerformed
        // TODO add your handling code here:
     MainHome home = new MainHome();
     home.setVisible(true);
     this.setVisible(false);
    }//GEN-LAST:event_LogoutActionPerformed

    private void manageOrdersActionPerformed(java.awt.event.ActionEvent evt) {
    	ManageAppointments view = new ManageAppointments();
     view.setVisible(true);
     this.setVisible(false);
        
    }
    
    private void AddItemActionPerformed(java.awt.event.ActionEvent evt) {                                        
        UpdateDocDetails bank = new UpdateDocDetails();
        bank.setVisible(true);
        this.setVisible(false);  
       }  
    
    private void managedeliveryActionPerformed(ActionEvent evt) {
		
		
	}


    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(HomePageProvider.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(HomePageProvider.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(HomePageProvider.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(HomePageProvider.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new HomePageProvider().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton AddBank;
    private javax.swing.JLabel Heading;
    private javax.swing.JButton Logout;
    private javax.swing.JButton manageOrders;
    private JButton btnNewButton;
}
