package telehealth.view;

import java.awt.BorderLayout;
import java.awt.Color;
import java.io.File;
import java.io.IOException;

import javax.swing.JPanel;
import javax.swing.table.DefaultTableModel;

import telehealth.controller.AppStatus;
import telehealth.model.AptDet;
import telehealth.model.PatientDetails;


public class ViewStatus1 extends javax.swing.JFrame {

private static final long serialVersionUID = 1L;
AppStatus obj = new AppStatus();
AptDet order0bj = new AptDet();
PatientDetails customer = new PatientDetails();
String username;
int i;
      
    public ViewStatus1() {
    	//getContentPane().setBackground(new Color(173, 216, 230));
    	try {
		    final java.awt.Image backgroundImage = javax.imageio.ImageIO.read(new File("C:\\images\\img1.jpg"));
		    setContentPane(new JPanel(new BorderLayout()) {
		        @Override public void paintComponent(java.awt.Graphics g) {
		            g.drawImage(backgroundImage, 0, 0, null);
		        }
		    });
		} catch (IOException e) {
		    throw new RuntimeException(e);
		}
    	initComponents();
    }

    ViewStatus1(String username) {
         //To change body of generated methods, choose Tools | Templates.
    	try {
		    final java.awt.Image backgroundImage = javax.imageio.ImageIO.read(new File("C:\\images\\img1.jpg"));
		    setContentPane(new JPanel(new BorderLayout()) {
		        @Override public void paintComponent(java.awt.Graphics g) {
		            g.drawImage(backgroundImage, 0, 0, null);
		        }
		    });
		} catch (IOException e) {
		    throw new RuntimeException(e);
		}     
    	initComponents();
          this.username = username;
          order0bj = customer.getAllStatus(username);
        String[] cols = {"Order ID","Order Name","Order Status","Customer Name","orderedDate"};
        DefaultTableModel table = new DefaultTableModel(cols,0);
        jTable1.setModel(table);
            
        for(i = 0;i<order0bj.id.size();i++){
            
            Object[] data = {order0bj.id.get(i),order0bj.name.get(i),order0bj.astatus.get(i),order0bj.pname.get(i),order0bj.aDate.get(i)};   
            table.addRow(data);
        }
          
          
    }


    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">                          
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        jScrollPane1.setForeground(Color.WHITE);
        jScrollPane1.setBackground(Color.GRAY);
        jTable1 = new javax.swing.JTable();
        jButton1 = new javax.swing.JButton();
        jButton1.setBackground(Color.GRAY);
        jButton1.setForeground(Color.WHITE);

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null,null,null},
                {null, null,null,null},
                {null, null,null,null},
            },
            new String [] {
                "App id", "Status","Patient name","Date"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(jTable1);

        jButton1.setText("Back");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(242, 242, 242)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 439, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(366, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(127, 127, 127))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(53, 53, 53)
                .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(41, 41, 41)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 145, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(165, Short.MAX_VALUE))
        );
        getContentPane().setBackground(new Color(173, 216, 230));
        pack();
    }                     

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {                                         
        PatientLogin home = new PatientLogin(username);
        home.setVisible(true);
        this.setVisible(false);
    }                                        
    public static void main(String args[]) {
     try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(ViewStatus1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(ViewStatus1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(ViewStatus1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(ViewStatus1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ViewStatus1().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify                     
    private javax.swing.JButton jButton1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    // End of variables declaration                   
}
