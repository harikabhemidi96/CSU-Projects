package telehealth.view;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Color;

public class MainHome extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					MainHome frame = new MainHome();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public MainHome() {
		setBackground(Color.PINK);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton btnNewButton = new JButton("SignUp");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				patActionPerformed(e);
		        
			}
		});
		btnNewButton.setBounds(36, 99, 89, 23);
		contentPane.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("Patient Login");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				loginActionPerformed(e);
			}
		});
		btnNewButton_1.setBounds(150, 99, 112, 23);
		contentPane.add(btnNewButton_1);
		
		JButton btnNewButton_2 = new JButton("Provider Login");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				pActionPerformed(e);
			}
		});
		btnNewButton_2.setBounds(272, 99, 117, 23);
		contentPane.add(btnNewButton_2);
		
		JLabel lblNewLabel = new JLabel("TELE-HEALTH");
		lblNewLabel.setForeground(Color.GRAY);
		lblNewLabel.setFont(new Font("Times New Roman", Font.ITALIC, 25));
		lblNewLabel.setBounds(132, 32, 197, 39);
		contentPane.add(lblNewLabel);
		
		JButton btnNewButton_3 = new JButton("Admin");
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				AdminActionPerformed(e);
			}
		});
		btnNewButton_3.setBounds(33, 11, 89, 23);
		contentPane.add(btnNewButton_3);
	}
	
	private void patActionPerformed(ActionEvent e) {
		 PatientUI reg = new PatientUI();
        reg.setVisible(true);
        this.setVisible(false);
		
	}
	
	private void pActionPerformed(ActionEvent e) {
		HomePageProviderUI u = new HomePageProviderUI();
		u.setVisible(true);
        this.setVisible(false);
		
	}
	
	
	
	private void AdminActionPerformed(ActionEvent e) {
		AdminUI adminUI = new AdminUI();
		adminUI.setVisible(true);
        this.setVisible(false);
		
	}
	
	private void loginActionPerformed(ActionEvent e) {
		LoginUI login = new LoginUI();
        login.setVisible(true);
        this.setVisible(false);
		
	}
}
