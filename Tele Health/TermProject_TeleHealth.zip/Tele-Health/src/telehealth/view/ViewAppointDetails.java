package telehealth.view;


import java.awt.BorderLayout;
import java.awt.Color;
import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.table.DefaultTableModel;

import telehealth.model.AppointmentData;
import telehealth.model.Appointments;
import telehealth.model.DoctorDetails;
import telehealth.model.PatientDetails;

import javax.swing.GroupLayout.Alignment;
import javax.swing.GroupLayout;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.JLabel;
import javax.swing.JComboBox;
import javax.swing.JCheckBox;

public class ViewAppointDetails extends javax.swing.JFrame {
    PatientDetails customer = new PatientDetails();
    DoctorDetails item = new DoctorDetails();
    Appointments app = new Appointments();
    int df = app.getNextAppID();
    int bi;
    int i;
    String username;
    ArrayList<AppointmentData> v;

    public ViewAppointDetails(String username, ArrayList<AppointmentData> orderDto) {
    	//getContentPane().setBackground(new Color(173, 216, 230));
    	try {
		    final java.awt.Image backgroundImage = javax.imageio.ImageIO.read(new File("C:\\images\\img1.jpg"));
		    setContentPane(new JPanel(new BorderLayout()) {
		        @Override public void paintComponent(java.awt.Graphics g) {
		            g.drawImage(backgroundImage, 0, 0, null);
		        }
		    });
		} catch (IOException e) {
		    throw new RuntimeException(e);
		}
    	initComponents();
 
       v=orderDto;
        String[] cols = {"Doctor Name","Date","Fee"};
        DefaultTableModel table = new DefaultTableModel(cols,0);
        jTable1.setModel(table);
            
        for(i = 0;i<orderDto.size();i++){
        	AppointmentData order=orderDto.get(i);
            Object[] data = {order.name,order.deliveryType,order.amount};
               
            table.addRow(data);
        }
        
        this.username = username;
    }


    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">                          
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel1.setForeground(Color.GRAY);
        orderplaced = new javax.swing.JButton();
        orderplaced.setForeground(Color.WHITE);
        orderplaced.setBackground(Color.GRAY);
        jButton2 = new javax.swing.JButton();
        jButton2.setBackground(Color.GRAY);
        jButton2.setForeground(Color.WHITE);
        jScrollPane1 = new javax.swing.JScrollPane();
        jScrollPane1.setForeground(Color.WHITE);
        jScrollPane1.setBackground(Color.GRAY);
        jTable1 = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setFont(new java.awt.Font("Times New Roman", 3, 18)); // NOI18N
        jLabel1.setText("View Appointment");

        orderplaced.setText("Book Appointment");
        orderplaced.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                placeAActionPerformed(evt);
            }
        });

        jButton2.setText("Back");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "itemname", "typeOfItem", "author", "price"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(jTable1);
        if (jTable1.getColumnModel().getColumnCount() > 0) {
            jTable1.getColumnModel().getColumn(0).setResizable(false);
            jTable1.getColumnModel().getColumn(1).setResizable(false);
            jTable1.getColumnModel().getColumn(2).setResizable(false);
            jTable1.getColumnModel().getColumn(3).setResizable(false);
        }
 int count = 0;
 
        
        lblNewLabel = new JLabel("Payment Type");
        lblNewLabel.setForeground(Color.GRAY);
        
        comboBox_1 = new JComboBox();
        comboBox_1.setBackground(Color.GRAY);
        int count1 = 0;
        String[] categories1 = {
         	    "Cash", "Debit","Credit"
         	  };
               for(int i = 0; i < categories1.length; i++)
            	   comboBox_1.addItem(categories1[count1++]);
        
        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        layout.setHorizontalGroup(
        	layout.createParallelGroup(Alignment.LEADING)
        		.addGroup(layout.createSequentialGroup()
        			.addGap(78)
        			.addGroup(layout.createParallelGroup(Alignment.LEADING)
        				.addGroup(layout.createSequentialGroup()
        					.addComponent(orderplaced, GroupLayout.PREFERRED_SIZE, 132, GroupLayout.PREFERRED_SIZE)
        					.addContainerGap())
        				.addGroup(layout.createSequentialGroup()
        					.addGroup(layout.createParallelGroup(Alignment.LEADING)
        						.addComponent(jScrollPane1, GroupLayout.PREFERRED_SIZE, 499, GroupLayout.PREFERRED_SIZE)
        						.addGroup(layout.createSequentialGroup()
        							.addComponent(jLabel1, GroupLayout.PREFERRED_SIZE, 362, GroupLayout.PREFERRED_SIZE)
        							.addPreferredGap(ComponentPlacement.RELATED, 527, Short.MAX_VALUE)
        							.addComponent(jButton2, GroupLayout.PREFERRED_SIZE, 144, GroupLayout.PREFERRED_SIZE))
        						.addGroup(layout.createSequentialGroup()
        							.addComponent(lblNewLabel)
        							.addGap(35)
        							.addComponent(comboBox_1, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)))
        					.addGap(153))))
        );
        layout.setVerticalGroup(
        	layout.createParallelGroup(Alignment.TRAILING)
        		.addGroup(layout.createSequentialGroup()
        			.addGap(19)
        			.addGroup(layout.createParallelGroup(Alignment.TRAILING)
        				.addGroup(layout.createSequentialGroup()
        					.addComponent(jLabel1, GroupLayout.PREFERRED_SIZE, 35, GroupLayout.PREFERRED_SIZE)
        					.addGap(30))
        				.addGroup(layout.createSequentialGroup()
        					.addComponent(jButton2, GroupLayout.PREFERRED_SIZE, 47, GroupLayout.PREFERRED_SIZE)
        					.addGap(52)))
        			.addPreferredGap(ComponentPlacement.RELATED)
        			.addComponent(jScrollPane1, GroupLayout.PREFERRED_SIZE, 181, GroupLayout.PREFERRED_SIZE)
        			.addGap(57)
        			.addGroup(layout.createParallelGroup(Alignment.LEADING)
        				.addComponent(lblNewLabel)
        				.addComponent(comboBox_1, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
        			.addPreferredGap(ComponentPlacement.RELATED)
        			.addComponent(orderplaced, GroupLayout.PREFERRED_SIZE, 47, GroupLayout.PREFERRED_SIZE)
        			.addContainerGap(GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        getContentPane().setLayout(layout);

        pack();
    }// </editor-fold>                        

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {                                         
    	PatientLogin home = new PatientLogin( username );
     home.setVisible(true);
     this.setVisible(false);
    }                                        

    private void placeAActionPerformed(java.awt.event.ActionEvent evt) {                                      
        // TODO add your handling code here:
		int count=0;  
        for (AppointmentData dc : v) {
	
        	Date date=new Date();
        	SimpleDateFormat sd=new SimpleDateFormat();   
        	dc.patAppId=Integer.toString(dc.appId);
        	dc.appStatus="Placed";
        
        	
        	dc.modeOfPayment=(String) comboBox_1.getSelectedItem();
        	dc.appId=dc.appId+count;
        	count++;
        	
		}
    	app.addorder(v);
        
    	JOptionPane.showMessageDialog(this, "Your Appointment is Booked!!!");
    	PatientLogin or=new PatientLogin(this.username);
    	or.setVisible(true);
        this.setVisible(false);
        
    }                                     
    private javax.swing.JButton orderplaced;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    private JLabel lblNewLabel;
    private JComboBox comboBox_1;
}
