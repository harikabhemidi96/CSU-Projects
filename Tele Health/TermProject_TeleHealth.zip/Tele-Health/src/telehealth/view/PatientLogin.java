package telehealth.view;

import java.awt.BorderLayout;
import java.awt.Color;
import java.io.File;
import java.io.IOException;

import javax.swing.JPanel;

public class PatientLogin extends javax.swing.JFrame {


		private static final long serialVersionUID = 1L;
		String username;
	    
	    public PatientLogin() {

	    	try {
			    final java.awt.Image backgroundImage = javax.imageio.ImageIO.read(new File("C:\\images\\img1.jpg"));
			    setContentPane(new JPanel(new BorderLayout()) {
			        @Override public void paintComponent(java.awt.Graphics g) {
			            g.drawImage(backgroundImage, 0, 0, null);
			        }
			    });
			} catch (IOException e) {
			    throw new RuntimeException(e);
			}
	    	initComponents();
	    }
        
	    PatientLogin(String username) {
	    	try {
			    final java.awt.Image backgroundImage = javax.imageio.ImageIO.read(new File("C:\\images\\img1.jpg"));
			    setContentPane(new JPanel(new BorderLayout()) {
			        @Override public void paintComponent(java.awt.Graphics g) {
			            g.drawImage(backgroundImage, 0, 0, null);
			        }
			    });
			} catch (IOException e) {
			    throw new RuntimeException(e);
			}
	        this.username = username;
	        initComponents();
	        
	    }
	    
	    private void initComponents() {

	        jLabel1 = new javax.swing.JLabel();
	        jLabel1.setForeground(Color.GRAY);
	        bb = new javax.swing.JButton();
	        bb.setForeground(Color.WHITE);
	        bb.setBackground(Color.GRAY);
	        viewstatusbtn = new javax.swing.JButton();
	        viewstatusbtn.setForeground(Color.WHITE);
	        viewstatusbtn.setBackground(Color.GRAY);
	        logoutbtn = new javax.swing.JButton();
	        logoutbtn.setForeground(Color.WHITE);
	        logoutbtn.setBackground(Color.GRAY);

	        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

	        jLabel1.setText("User Home Page: "+ this.username);

	        bb.setText("Book Appointment");
	        bb.addActionListener(new java.awt.event.ActionListener() {
	            public void actionPerformed(java.awt.event.ActionEvent evt) {
	                OrderActionPerformed(evt);
	            }
	        });

	        viewstatusbtn.setText("Appointment Status");
	        viewstatusbtn.addActionListener(new java.awt.event.ActionListener() {
	            public void actionPerformed(java.awt.event.ActionEvent evt) {
	                viewstatusbtnActionPerformed(evt);
	            }
	        });

	        logoutbtn.setText("Logout");
	        logoutbtn.addActionListener(new java.awt.event.ActionListener() {
	            public void actionPerformed(java.awt.event.ActionEvent evt) {
	                logoutbtnActionPerformed(evt);
	            }
	        });

	        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
	        getContentPane().setLayout(layout);
	        layout.setHorizontalGroup(
	            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
	            .addGroup(layout.createSequentialGroup()
	                .addGap(118, 118, 118)
	                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
	                    .addGroup(layout.createSequentialGroup()
	                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 324, javax.swing.GroupLayout.PREFERRED_SIZE)
	                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 163, Short.MAX_VALUE)
	                        .addComponent(logoutbtn, javax.swing.GroupLayout.PREFERRED_SIZE, 114, javax.swing.GroupLayout.PREFERRED_SIZE)
	                        .addGap(104, 104, 104))
	                    .addGroup(layout.createSequentialGroup()
	                        .addComponent(bb, javax.swing.GroupLayout.PREFERRED_SIZE, 188, javax.swing.GroupLayout.PREFERRED_SIZE)
	                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
	                        .addComponent(viewstatusbtn, javax.swing.GroupLayout.PREFERRED_SIZE, 149, javax.swing.GroupLayout.PREFERRED_SIZE)
	                        .addGap(162, 162, 162))))
	        );
	        layout.setVerticalGroup(
	            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
	            .addGroup(layout.createSequentialGroup()
	                .addGap(39, 39, 39)
	                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
	                    .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
	                    .addComponent(logoutbtn))
	                .addGap(49, 49, 49)
	                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
	                    .addComponent(bb, javax.swing.GroupLayout.PREFERRED_SIZE, 84, javax.swing.GroupLayout.PREFERRED_SIZE)
	                    .addComponent(viewstatusbtn, javax.swing.GroupLayout.PREFERRED_SIZE, 84, javax.swing.GroupLayout.PREFERRED_SIZE))
	                .addContainerGap(222, Short.MAX_VALUE))
	        );

	        pack();
	    }                       

	    private void logoutbtnActionPerformed(java.awt.event.ActionEvent evt) {                                          
MainHome home = new MainHome();
	     home.setVisible(true);
	     this.setVisible(false);
	    }                                         
	    private void OrderActionPerformed(java.awt.event.ActionEvent evt) {                                          
	     AppointmentDetails ad = new AppointmentDetails(username);
	     ad.setVisible(true);
	     this.setVisible(false);   
	    }                                         
	    private void viewstatusbtnActionPerformed(java.awt.event.ActionEvent evt) {                                              
	    	ViewStatus view = new ViewStatus(username);
	    	view.setVisible(true);
	        this.setVisible(false);   
	    }                                             


	    public static void main(String args[]) {
	        try {
	            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
	                if ("Nimbus".equals(info.getName())) {
	                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
	                    break;
	                }
	            }
	        } catch (ClassNotFoundException ex) {
	            java.util.logging.Logger.getLogger(PatientLogin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
	        } catch (InstantiationException ex) {
	            java.util.logging.Logger.getLogger(PatientLogin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
	        } catch (IllegalAccessException ex) {
	            java.util.logging.Logger.getLogger(PatientLogin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
	        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
	            java.util.logging.Logger.getLogger(PatientLogin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
	        }
	        java.awt.EventQueue.invokeLater(new Runnable() {
	            public void run() {
	                new PatientLogin().setVisible(true);
	            }
	        });
	    }

                   
	    private javax.swing.JButton bb;
	    private javax.swing.JLabel jLabel1;
	    private javax.swing.JButton logoutbtn;
	    private javax.swing.JButton viewstatusbtn;             
	}
