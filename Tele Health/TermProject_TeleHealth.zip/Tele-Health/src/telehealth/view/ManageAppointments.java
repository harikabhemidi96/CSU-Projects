
package telehealth.view;

import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.table.DefaultTableModel;

import telehealth.model.Appointments;
import telehealth.model.AptDet;
import telehealth.model.PatientDetails;

import javax.swing.JLabel;
import javax.swing.GroupLayout.Alignment;

import java.awt.BorderLayout;
import java.awt.Color;
import java.io.File;
import java.io.IOException;

import javax.swing.GroupLayout;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.JComboBox;
import javax.swing.ScrollPaneConstants;

public class ManageAppointments extends javax.swing.JFrame {

	private static final long serialVersionUID = 1L;
	PatientDetails customer = new PatientDetails();
    AptDet appobj;
    Appointments app = new Appointments();
    int i;

    public ManageAppointments() {
    	
    	try {
		    final java.awt.Image backgroundImage = javax.imageio.ImageIO.read(new File("C:\\images\\img1.jpg"));
		    setContentPane(new JPanel(new BorderLayout()) {
		        @Override public void paintComponent(java.awt.Graphics g) {
		            g.drawImage(backgroundImage, 0, 0, null);
		        }
		    });
		} catch (IOException e) {
		    throw new RuntimeException(e);
		}
    	initComponents();
        appobj = app.getAllAppoint();
        String[] cols = {"App ID","Doctor Name","Doctor Type","Fee","Patient ID"};
        DefaultTableModel table = new DefaultTableModel(cols,0);
        jTable1.setModel(table);
            
        for(i = 0;i<appobj.id.size();i++){
            Object[] data = {appobj.id.get(i),appobj.name.get(i),appobj.type.get(i),appobj.amount.get(i),appobj.pname.get(i)};
               
            table.addRow(data);
        }
        
    }

    @SuppressWarnings({ "unchecked", "serial" })                      
    private void initComponents() {
        jScrollPane1 = new javax.swing.JScrollPane(); 
        jScrollPane1.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
        jScrollPane1.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_ALWAYS);
        jScrollPane1.setForeground(Color.GRAY);
        jTable1 = new javax.swing.JTable();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel2.setForeground(Color.GRAY);
        id = new javax.swing.JTextField();
        submit = new javax.swing.JButton();
        submit.setBackground(Color.GRAY);
        submit.setForeground(Color.WHITE);
        back = new javax.swing.JButton();
        back.setForeground(Color.WHITE);
        back.setBackground(Color.GRAY);

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(Color.LIGHT_GRAY);

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "App id", "Doctor name", "Speciality", "Fee", "PatientName"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, true, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(jTable1);

        jLabel1.setFont(new java.awt.Font("Times New Roman", 3, 24)); 
        jLabel1.setForeground(Color.GRAY);
        jLabel1.setText("All Appointments");

        jLabel2.setText("App Id");

        id.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                idActionPerformed(evt);
            }
        });

        submit.setText("submit");
        submit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                submitActionPerformed(evt);
            }
        });

        back.setText("Back");
        back.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                backActionPerformed(evt);
            }
        });
        
        JLabel status = new JLabel();
        status.setForeground(Color.GRAY);
        status.setText("App Status");
        
      comboBox = new JComboBox();
      comboBox.setBackground(Color.GRAY);
      comboBox.setForeground(Color.WHITE);
//        String[] orderList = {
//        	    "Ordered", "Packed", "Shipped", "Out for Delivery",
//        	    "Delivered"
//        	  };
        
        String[] orderList = {
        	    "Booked", "Not Available","Pending"};
        
        int count = 0;
	       for(int i = 0; i < orderList.length; i++)
	    	   comboBox.addItem(orderList[count++]);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        layout.setHorizontalGroup(
        	layout.createParallelGroup(Alignment.TRAILING)
        		.addGroup(layout.createSequentialGroup()
        			.addGroup(layout.createParallelGroup(Alignment.LEADING)
        				.addGroup(layout.createSequentialGroup()
        					.addGap(82)
        					.addComponent(jLabel1, GroupLayout.PREFERRED_SIZE, 422, GroupLayout.PREFERRED_SIZE))
        				.addGroup(layout.createSequentialGroup()
        					.addGap(39)
        					.addComponent(jScrollPane1, GroupLayout.PREFERRED_SIZE, 358, GroupLayout.PREFERRED_SIZE)
        					.addGap(80)
        					.addGroup(layout.createParallelGroup(Alignment.LEADING)
        						.addComponent(jLabel2, GroupLayout.PREFERRED_SIZE, 102, GroupLayout.PREFERRED_SIZE)
        						.addComponent(status, GroupLayout.PREFERRED_SIZE, 102, GroupLayout.PREFERRED_SIZE))
        					.addGap(18)
        					.addGroup(layout.createParallelGroup(Alignment.LEADING)
        						.addComponent(id, GroupLayout.PREFERRED_SIZE, 155, GroupLayout.PREFERRED_SIZE)
        						.addComponent(comboBox, 0, 96, Short.MAX_VALUE))))
        			.addContainerGap(280, GroupLayout.PREFERRED_SIZE))
        		.addGroup(layout.createSequentialGroup()
        			.addGap(0, 542, Short.MAX_VALUE)
        			.addGroup(layout.createParallelGroup(Alignment.TRAILING)
        				.addGroup(layout.createSequentialGroup()
        					.addComponent(submit, GroupLayout.PREFERRED_SIZE, 151, GroupLayout.PREFERRED_SIZE)
        					.addGap(339))
        				.addGroup(layout.createSequentialGroup()
        					.addComponent(back, GroupLayout.PREFERRED_SIZE, 102, GroupLayout.PREFERRED_SIZE)
        					.addGap(176))))
        );
        layout.setVerticalGroup(
        	layout.createParallelGroup(Alignment.LEADING)
        		.addGroup(layout.createSequentialGroup()
        			.addContainerGap(82, Short.MAX_VALUE)
        			.addComponent(back)
        			.addPreferredGap(ComponentPlacement.RELATED)
        			.addComponent(jLabel1, GroupLayout.PREFERRED_SIZE, 59, GroupLayout.PREFERRED_SIZE)
        			.addGap(29)
        			.addGroup(layout.createParallelGroup(Alignment.LEADING)
        				.addComponent(jScrollPane1, GroupLayout.PREFERRED_SIZE, 102, GroupLayout.PREFERRED_SIZE)
        				.addGroup(layout.createSequentialGroup()
        					.addGroup(layout.createParallelGroup(Alignment.BASELINE)
        						.addComponent(jLabel2)
        						.addComponent(id, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
        					.addPreferredGap(ComponentPlacement.UNRELATED)
        					.addGroup(layout.createParallelGroup(Alignment.BASELINE)
        						.addComponent(status)
        						.addComponent(comboBox, GroupLayout.PREFERRED_SIZE, 18, GroupLayout.PREFERRED_SIZE))))
        			.addGap(131)
        			.addComponent(submit, GroupLayout.PREFERRED_SIZE, 45, GroupLayout.PREFERRED_SIZE)
        			.addGap(19))
        );
        getContentPane().setLayout(layout);

        pack();
    }                       

    private void idActionPerformed(java.awt.event.ActionEvent evt) {                                   
        // TODO add your handling code here:
    }                                  

    private void submitActionPerformed(java.awt.event.ActionEvent evt) {   
    	String orderid = id.getText();
        if(id.getText().equals("")){
             JOptionPane.showMessageDialog(this, "All fields are Mandatory");
         }
//        else if(id.getText().equals(customer.getOrderStatusByID(orderid)))
//        {
//        	JOptionPane.showMessageDialog(this, "Given OrderId Already Processed");
//        }
        else 
        {
        	customer.aStatus(id.getText(),comboBox.getSelectedItem().toString());    
            JOptionPane.showMessageDialog(this, "Status updated");
            HomePageProvider home = new HomePageProvider();
     home.setVisible(true);
     this.setVisible(false);
        }
    }                                      

    private void backActionPerformed(java.awt.event.ActionEvent evt) {                                     
     HomePageProvider home = new HomePageProvider();
     home.setVisible(true);
     this.setVisible(false);
    }                                    

    public static void main(String args[]) {
         try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(ManageAppointments.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(ManageAppointments.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(ManageAppointments.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(ManageAppointments.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
       

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ManageAppointments().setVisible(true);
            }
        });
    }
                 
    private javax.swing.JButton back;
    private javax.swing.JTextField id;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JButton submit;
    private JComboBox comboBox;
}
