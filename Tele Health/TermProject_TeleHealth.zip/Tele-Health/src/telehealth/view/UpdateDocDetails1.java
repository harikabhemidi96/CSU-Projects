package telehealth.view;

import javax.swing.JComboBox;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.GroupLayout.Alignment;

import java.awt.BorderLayout;
import java.awt.Color;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

import javax.swing.GroupLayout;
import javax.swing.LayoutStyle.ComponentPlacement;

import telehealth.model.DoctorDetails;
import telehealth.model.DoctorType;
import telehealth.model.Primarycaredoctors;
import telehealth.model.Specialtydoctors;

import javax.swing.JLabel;

public class UpdateDocDetails1 extends javax.swing.JFrame {

	private static final long serialVersionUID = 1L;
	DoctorDetails item = new DoctorDetails();

	public UpdateDocDetails1() {
		//getContentPane().setBackground(new Color(173, 216, 230));
		try {
		    final java.awt.Image backgroundImage = javax.imageio.ImageIO.read(new File("C:\\images\\img1.jpg"));
		    setContentPane(new JPanel(new BorderLayout()) {
		        @Override public void paintComponent(java.awt.Graphics g) {
		            g.drawImage(backgroundImage, 0, 0, null);
		        }
		    });
		} catch (IOException e) {
		    throw new RuntimeException(e);
		}
		initComponents();
	}

	@SuppressWarnings("unchecked")
	private void initComponents() {

		jLabel1 = new javax.swing.JLabel();
		jLabel2 = new javax.swing.JLabel();
		jLabel2.setForeground(Color.GRAY);
		itemid = new javax.swing.JTextField();
		jLabel3 = new javax.swing.JLabel();
		jLabel3.setForeground(Color.GRAY);
		itemname = new javax.swing.JTextField();
		jLabel4 = new javax.swing.JLabel();
		jLabel5 = new javax.swing.JLabel();
		jLabel5.setForeground(Color.GRAY);
		price = new javax.swing.JTextField();
		jLabel6 = new javax.swing.JLabel();
		ap = new javax.swing.JButton();
		ap.setBackground(Color.GRAY);
		ap.setForeground(Color.WHITE);
		back = new javax.swing.JButton();
		back.setBackground(Color.GRAY);
		back.setForeground(Color.WHITE);
		update = new javax.swing.JButton();
		update.setBackground(Color.GRAY);
		update.setForeground(Color.WHITE);
		delete = new javax.swing.JButton();
		delete.setBackground(Color.GRAY);
		delete.setForeground(Color.WHITE);
		jLabel7 = new javax.swing.JLabel();
		jLabel7.setForeground(Color.GRAY);
		comboBox_1 = new JComboBox();

		String[] categories = { "PrimaryCARE", "Specialitydoctors" };

		String[] subType1;

		String[] subType2;

		setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

		jLabel1.setFont(new java.awt.Font("Times New Roman", 3, 24)); // NOI18N
		jLabel1.setForeground(Color.GRAY);
		jLabel1.setText("Update Doctor Details");

		jLabel2.setText("Doctor id");

		jLabel3.setText("Doctor Name");

//	        jLabel4.setText("Author");
//
		jLabel5.setText("Fee");
//
//	        jLabel6.setText("Publisher");

		ap.setText("Add");
		ap.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				additemActionPerformed(evt);
			}
		});

		back.setText("Back");
		back.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				backActionPerformed(evt);
			}
		});

		update.setText("Update");
		update.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				updateActionPerformed(evt);
			}
		});

		delete.setText("Delete");
		delete.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				deleteActionPerformed(evt);
			}
		});

		jLabel7.setText("Speciality");

		int count = 0;

		for (int i = 0; i < categories.length; i++)
			comboBox_1.addItem(categories[count++]);

		JLabel itemType = new JLabel("Type Of Doctor");
		itemType.setForeground(Color.GRAY);

		itemsubType = new JComboBox();

		comboBox_1.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				String itemselected = (String) comboBox_1.getSelectedItem();
				String fictionvar = "PrimaryCARE";
				
				int count = 0;
				itemsubType.removeAllItems();
				ArrayList<String> array = new ArrayList<String>();
				if (itemselected.equals(fictionvar)) {

					DoctorType cs = new DoctorType(new Primarycaredoctors());
					array = (cs.getFoodItems());
					String[] finalarray = array.toArray(new String[array.size()]);
					for (int i = 0; i < finalarray.length; i++)
						itemsubType.addItem(finalarray[count++]);
				} else {
					DoctorType cs = new DoctorType(new Specialtydoctors());
					array = cs.getFoodItems();
					String[] finalarray = array.toArray(new String[array.size()]);
					for (int i = 0; i < finalarray.length; i++)
						itemsubType.addItem(finalarray[count++]);
				}
			}
		});

		// String[] array = arrayList.toArray(new String[arrayList.size()]);

		javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
		layout.setHorizontalGroup(layout.createParallelGroup(Alignment.LEADING).addGroup(layout.createSequentialGroup()
				.addGap(125)
				.addGroup(layout.createParallelGroup(Alignment.LEADING).addGroup(layout.createSequentialGroup()
						.addComponent(itemType, GroupLayout.DEFAULT_SIZE, 798, Short.MAX_VALUE).addContainerGap())
						.addGroup(
								layout.createSequentialGroup()
										.addComponent(jLabel7, GroupLayout.PREFERRED_SIZE, 74,
												GroupLayout.PREFERRED_SIZE)
										.addContainerGap())
						.addGroup(layout.createSequentialGroup()
								.addComponent(jLabel1, GroupLayout.PREFERRED_SIZE, 316, GroupLayout.PREFERRED_SIZE)
								.addPreferredGap(ComponentPlacement.RELATED, 239, Short.MAX_VALUE)
								.addComponent(back, GroupLayout.PREFERRED_SIZE, 121, GroupLayout.PREFERRED_SIZE)
								.addGap(132))
						.addGroup(layout.createSequentialGroup().addGroup(layout
								.createParallelGroup(Alignment.TRAILING, false)
								.addGroup(layout.createSequentialGroup()
										.addGroup(layout.createParallelGroup(Alignment.LEADING)
												.addGroup(layout.createSequentialGroup()
														.addGroup(layout.createParallelGroup(Alignment.LEADING, false)
																.addComponent(jLabel3, GroupLayout.DEFAULT_SIZE,
																		GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
																.addComponent(jLabel4, GroupLayout.DEFAULT_SIZE,
																		GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
																.addComponent(jLabel6, GroupLayout.DEFAULT_SIZE,
																		GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
																.addComponent(jLabel2, Alignment.TRAILING,
																		GroupLayout.DEFAULT_SIZE, 83, Short.MAX_VALUE))
														.addGap(115))
												.addGroup(layout.createSequentialGroup()
														.addComponent(jLabel5, GroupLayout.DEFAULT_SIZE,
																GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
														.addPreferredGap(ComponentPlacement.RELATED)))
										.addGroup(layout.createParallelGroup(Alignment.LEADING).addComponent(itemname)
												.addGroup(layout.createSequentialGroup().addComponent(itemid)
														.addPreferredGap(ComponentPlacement.RELATED))
												.addComponent(price, Alignment.TRAILING)
												.addComponent(comboBox_1, 0, 218, Short.MAX_VALUE)
												.addComponent(itemsubType, 0, 218, Short.MAX_VALUE)))
								.addGroup(layout.createSequentialGroup()
										.addComponent(ap, GroupLayout.PREFERRED_SIZE, 111,
												GroupLayout.PREFERRED_SIZE)
										.addPreferredGap(ComponentPlacement.RELATED, 172, Short.MAX_VALUE).addComponent(
												update, GroupLayout.PREFERRED_SIZE, 133, GroupLayout.PREFERRED_SIZE)))
								.addGap(123)
								.addComponent(delete, GroupLayout.PREFERRED_SIZE, 149, GroupLayout.PREFERRED_SIZE)
								.addGap(1)))));
		layout.setVerticalGroup(
				layout.createParallelGroup(Alignment.LEADING)
						.addGroup(layout.createSequentialGroup().addContainerGap()
								.addGroup(layout.createParallelGroup(Alignment.BASELINE)
										.addComponent(jLabel1, GroupLayout.PREFERRED_SIZE, 62,
												GroupLayout.PREFERRED_SIZE)
										.addComponent(back, GroupLayout.PREFERRED_SIZE, 42, GroupLayout.PREFERRED_SIZE))
								.addGap(18)
								.addGroup(layout.createParallelGroup(Alignment.BASELINE).addComponent(jLabel2)
										.addComponent(itemid, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE,
												GroupLayout.PREFERRED_SIZE))
								.addGap(18).addGroup(layout
										.createParallelGroup(Alignment.BASELINE).addComponent(jLabel3).addComponent(
												itemname, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE,
												GroupLayout.PREFERRED_SIZE))
								.addGap(18)
								.addGroup(
										layout.createParallelGroup(Alignment.TRAILING)
												.addGroup(layout.createSequentialGroup()
														.addComponent(price, GroupLayout.PREFERRED_SIZE,
																GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
														.addGap(18)
														.addComponent(comboBox_1, GroupLayout.PREFERRED_SIZE, 22,
																GroupLayout.PREFERRED_SIZE)
														.addGap(18)
														.addComponent(itemsubType, GroupLayout.PREFERRED_SIZE,
																GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
												.addGroup(layout.createSequentialGroup().addComponent(jLabel4)
														.addPreferredGap(ComponentPlacement.RELATED)
														.addComponent(jLabel5).addGap(19)
														.addComponent(
																jLabel7, GroupLayout.DEFAULT_SIZE, 28, Short.MAX_VALUE)
														.addGap(18)
														.addGroup(layout
																.createParallelGroup(Alignment.LEADING)
																.addComponent(itemType, GroupLayout.DEFAULT_SIZE, 25,
																		Short.MAX_VALUE)
																.addComponent(jLabel6, Alignment.TRAILING))))
								.addGap(147)
								.addGroup(layout.createParallelGroup(Alignment.TRAILING)
										.addGroup(layout.createSequentialGroup()
												.addGroup(layout.createParallelGroup(Alignment.BASELINE)
														.addComponent(update, GroupLayout.PREFERRED_SIZE, 41,
																GroupLayout.PREFERRED_SIZE)
														.addComponent(delete, GroupLayout.PREFERRED_SIZE, 41,
																GroupLayout.PREFERRED_SIZE))
												.addContainerGap())
										.addComponent(ap, GroupLayout.PREFERRED_SIZE, 41,
												GroupLayout.PREFERRED_SIZE))));
		getContentPane().setLayout(layout);

		pack();
	}

	private void backActionPerformed(java.awt.event.ActionEvent evt) {
		HomePageProvider home = new HomePageProvider();
		home.setVisible(true);
		this.setVisible(false);
	}

	private void additemActionPerformed(java.awt.event.ActionEvent evt) {
		if (itemid.getText().equals("") && itemname.getText().equals("") && price.getText().equals("")) {
			JOptionPane.showMessageDialog(this, "All fields are Mandatory");
		}
//	         else if(author.getText().equals("")){
//	            JOptionPane.showMessageDialog(this, "Enter valid AuthorID");
//	        }
		else {
			item.addDoc(itemid.getText(), itemname.getText(), price.getText(), comboBox_1.getSelectedItem().toString(),
					itemsubType.getSelectedItem().toString());
			JOptionPane.showMessageDialog(this, "Doctor Details Added!!");
			HomePageProvider home = new HomePageProvider();
			home.setVisible(true);
			this.setVisible(false);
		}
	}

	private void updateActionPerformed(java.awt.event.ActionEvent evt) {
		if (itemid.getText().equals("") && itemname.getText().equals("") && price.getText().equals("")) {
			JOptionPane.showMessageDialog(this, "All fields are Mandatory");
		}
//	         else if(author.getText().equals("")){
//	            JOptionPane.showMessageDialog(this, "Enter valid AuthorID");
//	        }
		else {
			item.updateDoc(itemid.getText(), itemname.getText(), price.getText(),
					itemsubType.getSelectedItem().toString(), comboBox_1.getSelectedItem().toString());
			JOptionPane.showMessageDialog(this, "Doctor Details Updated!!");
			HomePageProvider home = new HomePageProvider();
			home.setVisible(true);
			this.setVisible(false);
		}
	}

	private void deleteActionPerformed(java.awt.event.ActionEvent evt) {
		if (itemid.getText().equals("")) {
			JOptionPane.showMessageDialog(this, "Enter Valid ID");
		} else {

			item.deleteDoc(itemid.getText());
			JOptionPane.showMessageDialog(this, "Doctor Details Deleted!!"); // then show error meesage
			HomePageProvider home = new HomePageProvider();
			home.setVisible(true);
			this.setVisible(false);
		}

	}

	public static void main(String args[]) {
		try {
			for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
				if ("Nimbus".equals(info.getName())) {
					javax.swing.UIManager.setLookAndFeel(info.getClassName());
					break;
				}
			}
		} catch (ClassNotFoundException ex) {
			java.util.logging.Logger.getLogger(UpdateDocDetails1.class.getName()).log(java.util.logging.Level.SEVERE, null,
					ex);
		} catch (InstantiationException ex) {
			java.util.logging.Logger.getLogger(UpdateDocDetails1.class.getName()).log(java.util.logging.Level.SEVERE, null,
					ex);
		} catch (IllegalAccessException ex) {
			java.util.logging.Logger.getLogger(UpdateDocDetails1.class.getName()).log(java.util.logging.Level.SEVERE, null,
					ex);
		} catch (javax.swing.UnsupportedLookAndFeelException ex) {
			java.util.logging.Logger.getLogger(UpdateDocDetails1.class.getName()).log(java.util.logging.Level.SEVERE, null,
					ex);
		}

		java.awt.EventQueue.invokeLater(new Runnable() {
			public void run() {
				new UpdateDocDetails1().setVisible(true);
			}
		});
	}

	// Variables declaration - do not modify
	private javax.swing.JButton ap;
	private javax.swing.JButton back;
	private javax.swing.JTextField itemid;
	private javax.swing.JTextField itemname;
	private javax.swing.JButton delete;
	private javax.swing.JLabel jLabel1;
	private javax.swing.JLabel jLabel2;
	private javax.swing.JLabel jLabel3;
	private javax.swing.JLabel jLabel4;
	private javax.swing.JLabel jLabel5;
	private javax.swing.JLabel jLabel6;
	private javax.swing.JLabel jLabel7;
	private javax.swing.JTextField price;
	private javax.swing.JButton update;
	private javax.swing.JComboBox comboBox_1;
	private javax.swing.JComboBox itemsubType;
	private String Selectetype;
}
