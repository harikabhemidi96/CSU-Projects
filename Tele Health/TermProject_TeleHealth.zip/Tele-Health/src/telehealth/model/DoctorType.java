package telehealth.model;

import java.util.ArrayList;

public class DoctorType {
	private IDoctorType type;
	
	public DoctorType(IDoctorType docType) 
	{
		this.type= docType;
	}
	public ArrayList<String> getFoodItems()
	{
	return type.getDoctortype();	
	}

}
