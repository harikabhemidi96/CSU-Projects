package telehealth.model;

import java.util.ArrayList;

public class Specialtydoctors implements IDoctorType {

 
	public ArrayList<String> getDoctortype() {

        
		ArrayList<String> type2 = new ArrayList<String>();  
		  type2.add("Allergists");
		  type2.add("Endocrinologists");
		  type2.add("Gastroenterologists");
		 
		  
		return type2;
	}
}
