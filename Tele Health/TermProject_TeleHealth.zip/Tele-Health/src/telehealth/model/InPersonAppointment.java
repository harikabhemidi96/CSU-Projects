package telehealth.model;

public class InPersonAppointment extends AppointmentDecorator {

	HospitalAppointment addOns;
	
	public InPersonAppointment(HospitalAppointment addOn) {
		this.addOns=addOn;
	}
	@Override
	public int getFee() {
		// TODO Auto-generated method stub
		return 10 + addOns.getFee();
	}

}
