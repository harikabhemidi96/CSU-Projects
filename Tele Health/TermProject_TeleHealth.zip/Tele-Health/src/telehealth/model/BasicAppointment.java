package telehealth.model;

public class BasicAppointment extends HospitalAppointment{

	@Override
	public int getFee() {
		// TODO Auto-generated method stub
		return 0;
	}

}
