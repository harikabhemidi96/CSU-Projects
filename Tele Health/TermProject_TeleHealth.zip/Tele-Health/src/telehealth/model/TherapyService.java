package telehealth.model;

public class TherapyService extends AppointmentDecorator {

	HospitalAppointment addOns;

	public TherapyService(HospitalAppointment addOn) {
		this.addOns = addOn;
	}

	@Override
	public int getFee() {
		// TODO Auto-generated method stub
		return 20 + addOns.getFee();
	}

}
