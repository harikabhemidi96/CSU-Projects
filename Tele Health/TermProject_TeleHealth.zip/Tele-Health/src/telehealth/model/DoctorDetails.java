package telehealth.model;

import java.util.ArrayList;

import telehealth.controller.DataDefinitionQueries;
import telehealth.controller.DataManipulationQueries;
import telehealth.controller.IDataDefinition;
import telehealth.controller.IDataManipulation;

public class DoctorDetails {

	public String doctorid;
	public String doctorname;
	public String fee;
	public String specialization;

	IDataDefinition ddl = (IDataDefinition) new DataDefinitionQueries();
	IDataManipulation dml = (IDataManipulation) new DataManipulationQueries();

	public String getdocname(String doctorid) {
		doctorname = ddl.getDocName(doctorid);
		return doctorname;
	}

	public Object getDocid() {
		doctorid = ddl.getdoctorid();
		return doctorid;

	}

	public void addDoc(String doctorid, String doctorname, String fee, String specialization, String specializationType) {
		dml.adddocdet(doctorid, doctorname, fee, specialization, specializationType);
	}

	public ArrayList<DoctorDetails> viewallDoc() {
		return ddl.viewallDoc();
	}

	public void deleteDoc(String doctorid) {
		dml.deletedoc(doctorid);
	}

	public void updateDoc(String doctorid, String doctorname, String fee, String specialization, String specializationType) {
		dml.updatedoc(doctorid, doctorname, fee, specialization, specializationType);
	}

}
