package telehealth.model;

import java.util.ArrayList;

public class Primarycaredoctors implements IDoctorType{

	@Override
	public ArrayList<String> getDoctortype() {
		
		  ArrayList<String> doctorType = new ArrayList<String>();  
		  doctorType.add("InternalMedicine");
		  doctorType.add("FamilyMedicine");
		  doctorType.add("GeneralMedicine");
 
		return doctorType;
	}

}
