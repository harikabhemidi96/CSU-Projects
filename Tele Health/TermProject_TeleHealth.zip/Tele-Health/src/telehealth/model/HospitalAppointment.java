package telehealth.model;

public abstract class HospitalAppointment {

	public abstract int getFee();
}
