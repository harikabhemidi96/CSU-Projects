package telehealth.model;

import java.util.ArrayList;
import java.util.Date;

import telehealth.controller.DataDefinitionQueries;
import telehealth.controller.DataManipulationQueries;
import telehealth.controller.IDataDefinition;
import telehealth.controller.IDataManipulation;

public class Appointments {

	public Integer appid;
	private String type;
	private String amount;
	public int nextappid;
	private String appStatus;
	public Date date;
	IDataDefinition ddl = (IDataDefinition) new DataDefinitionQueries();
	IDataManipulation dml = (IDataManipulation) new DataManipulationQueries();

	public AppointmentData addApptolist(DoctorConfirmed item, int orderId) {
		AppointmentData app=new AppointmentData();
		HospitalAppointment addOns = new BasicAppointment();
		DoctorDetails item2 = ddl.viewallDocbasedonName(item.getDoctorName());
		System.out.println(item2.fee);
		int cost = Integer.parseInt(item2.fee);
		if (item.isInPerson()) {
			addOns = new InPersonAppointment(addOns);
		}

		if (item.isVirtual()) {
			addOns = new VirtualAppointment(addOns, 1);
		}

		if (item.getserviceType() == "1") {

			addOns = new EmergencyService(addOns);
			switch (item.getaType()) {
			case "1": {
				addOns = new FirstVisit (addOns);
				break;

			}
			case "2": {
				addOns = new SecondVisit(addOns);
				break;

			}
			
			case "3": {
				addOns = new MonthlyVisit(addOns);
				break;

			}
			
			default:
				throw new IllegalArgumentException("Unexpected value: " + item.getaType());
			}
		}

		if (item.getserviceType() == "2") {

			addOns = new InHomeNurse(addOns);
			switch (item.getaType()) {
			case "1": {
				addOns = new FirstVisit (addOns);
				break;

			}
			case "2": {
				addOns = new SecondVisit(addOns);
				break;

			}
			
			case "3": {
				addOns = new MonthlyVisit(addOns);
				break;

			}
			
			default:
				throw new IllegalArgumentException("Unexpected value: " + item.getaType());
			}
		}

		

		app.amount=Integer.toString(addOns.getFee() + cost);
		app.name=item.getDoctorName();
		app.type=item2.specialization;
		app.appId=orderId;
		app.deliveryType=item.getDate();
		return app;
	}

	public void addorder(ArrayList<AppointmentData> appData) {	
	    for (AppointmentData app : appData) {
	    	dml.adddocdetails(app.name, app.type, app.amount, app.patName, app.appId, app.modeOfPayment, app.deliveryType, app.patAppId);
		} 
		
	}

	public AptDet getAllAppoint() {
		AptDet appobj;
		appobj = ddl.allApp();
		return appobj;
	}

	public int getNextAppID() {
		nextappid = ddl.retrieveNextDocID();
		return nextappid; // To change body of generated methods, choose Tools | Templates.
	}

}
