package telehealth.model;

import java.util.ArrayList;

public interface IDoctorType {
	public  ArrayList<String> getDoctortype();	

}
