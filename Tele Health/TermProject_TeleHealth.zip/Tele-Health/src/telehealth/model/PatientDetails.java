package telehealth.model;

import telehealth.controller.DataDefinitionQueries;
import telehealth.controller.DataManipulationQueries;
import telehealth.controller.IDataDefinition;
import telehealth.controller.IDataManipulation;
import telehealth.controller.AppStatus;

public class PatientDetails {
    
    String name;
    String username;
    String user_email;
    String password;

	public void setorderid(int orderid) {
		this.orderid = orderid;
	}
	String user_mobile;
    String user_address;
    int orderid;
    IDataDefinition ddl = (IDataDefinition) new DataDefinitionQueries();
    IDataManipulation dml = (IDataManipulation) new DataManipulationQueries();
    public  void register(String name, String username, String user_email, String mobile, String password,String user_address) {
        //To change body of generated methods, choose Tools | Templates.\
        dml.register(name, username, user_email, mobile, password,user_address);
    }
	public Object login(String userName) {
		 password = ddl.login(userName);
	  return password;
	}
	public void aStatus(String orderid,String status) {
		 dml.appointStatus(orderid,status);
		
	}
	public AptDet getAllStatus(String username2) {
		return ddl.allStatus(username2);
	        
	}
	
    
//	public String getOrderStatusByID(String orderid) {
//		 return ddl.getOrderStatusByID(orderid);
//		
//	}
}


