package telehealth.model;

public class MonthlyVisit extends AppointmentDecorator {

	HospitalAppointment addOns;
	
	public MonthlyVisit(HospitalAppointment addOn) {
		this.addOns=addOn;
	}
	@Override
	public int getFee() {
		// TODO Auto-generated method stub
		return 20 + addOns.getFee();
	}

}
