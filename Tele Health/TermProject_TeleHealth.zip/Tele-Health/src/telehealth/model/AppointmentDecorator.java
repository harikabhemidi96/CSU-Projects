package telehealth.model;

public abstract class AppointmentDecorator extends HospitalAppointment {

}
