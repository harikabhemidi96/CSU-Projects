/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package telehealth.model;

import java.util.Observable;


public class DermatologyApt extends Observable {
    
    private final String count = "20";

    public String getcount() {
        return count;
    }
    
    public void aptAvailable(){
        setChanged();
        notifyObservers();
        
      
    }
    
    
    
}
