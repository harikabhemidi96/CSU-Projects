package telehealth.model;

public class EmergencyAppointment extends AppointmentDecorator {

	HospitalAppointment addOns;
	
	public EmergencyAppointment(HospitalAppointment addOn) {
		this.addOns=addOn;
	}
	@Override
	public int getFee() {
		// TODO Auto-generated method stub
		return 10 + addOns.getFee();
	}

}
