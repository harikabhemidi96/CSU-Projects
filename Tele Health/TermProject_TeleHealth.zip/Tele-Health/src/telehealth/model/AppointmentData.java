package telehealth.model;

public class AppointmentData {

	public int appId;
	public String name;
	public String type;
	public String amount;
	public String patName;
	public String appStatus;
	public String bookedDate;
	public String deliveryType;
	public String modeOfPayment;
	public String patAppId;

}
