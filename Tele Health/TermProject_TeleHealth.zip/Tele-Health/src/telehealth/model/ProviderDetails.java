package telehealth.model;

import telehealth.controller.DataDefinitionQueries;
import telehealth.controller.DataManipulationQueries;
import telehealth.controller.IDataDefinition;
import telehealth.controller.IDataManipulation;

public class ProviderDetails {
    String name;
    String emailId;
    String password;
    String mobile;
    String address;
    IDataDefinition ddl = (IDataDefinition) new DataDefinitionQueries();
    IDataManipulation dml = (IDataManipulation) new DataManipulationQueries();
    
    public String plogin(String userName)
     {
        password = ddl.providerlogin(userName);
        return password;
    }
     
    public String getproviderAddress(String userName)
     {
       address = ddl.getproviderAddress(userName);
       return address;
    }
       public String getproviderMobileNumber(String userName){
       mobile= ddl.getproviderMobileNumber(userName);
       return mobile;
        }
       
       public String getProviderEmailID(String userName){
       emailId = ddl.getproviderEmailID(userName);
       return emailId;
    }      

   public  void provSet(String name, String password, String email, String mobile, String address) {
        dml.setdoctor(name, password, email, mobile, address);
    }

    public void provUp(String name, String password, String email, String mobile, String address) {
         dml.updateDoc(name, password, email, mobile, address);
    }

    public void delPro(String name) {
         dml.deleteDoc(name);
    }

    
}
