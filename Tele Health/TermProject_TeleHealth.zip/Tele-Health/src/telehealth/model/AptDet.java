package telehealth.model;

import java.util.ArrayList;

public class AptDet {
    public ArrayList<Integer> id = new ArrayList();
    public ArrayList<String> name = new ArrayList();
    public ArrayList<String> type = new ArrayList();
    public ArrayList<String> amount = new ArrayList();
    public ArrayList<String> pname = new ArrayList();
    public ArrayList<String> astatus = new ArrayList();
    public ArrayList<String> aDate = new ArrayList();
	
    
}