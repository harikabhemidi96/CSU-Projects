package telehealth.model;

public class TypeofPayment {

	
	 public static String[] categories = {
     	    "Cash On Delivery", "UPI Payment","Credit/Debit card"
     	  };
}
