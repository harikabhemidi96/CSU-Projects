package telehealth.model;

public class VirtualAppointment extends AppointmentDecorator {

	HospitalAppointment addOns;
	int num;
	
	public VirtualAppointment(HospitalAppointment addOn,int num) {
		this.addOns=addOn;
		this.num=num;
	}
	@Override
	public int getFee() {
		// TODO Auto-generated method stub
		return 5*num + addOns.getFee();
	}

}
