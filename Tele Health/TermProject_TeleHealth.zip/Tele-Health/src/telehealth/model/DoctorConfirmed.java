package telehealth.model;

public class DoctorConfirmed {

	private String doctorName;
	private boolean isInPerson;
	private boolean isVirtual;
	private String aType;
	private String serviceType;
	private String cost;
	private String date;
	public boolean isVirtual() {
		return isVirtual;
	}
	public void setIsVirtual(boolean iv) {
		this.isVirtual = iv;
	}

	
	public String getDoctorName() {
		return doctorName;
	}
	public void setDocName(String dn) {
		this.doctorName = dn;
	}
	public boolean isInPerson() {
		return isInPerson;
	}
	public void setInPerson(boolean ip) {
		this.isInPerson = ip;
	}

	public String getaType() {
		return aType;
	}
	public void setaType(String ty) {
		this.aType = ty;
	}
	public String getserviceType() {
		return serviceType;
	}
	public void setserviceType(String st) {
		this.serviceType = st;
	}
	public String getcost() {
		return cost;
	}
	public void setCost(String c) {
		this.cost = c;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	
}
