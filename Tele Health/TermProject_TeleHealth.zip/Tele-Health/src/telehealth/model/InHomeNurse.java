package telehealth.model;

public class InHomeNurse extends AppointmentDecorator {

	HospitalAppointment ha;
	
	public InHomeNurse(HospitalAppointment a) {
		this.ha=a;
	}
	@Override
	public int getFee() {
		// TODO Auto-generated method stub
		return 30 + ha.getFee();
	}

}
